موسوعة المنشاوي الصوتية Pro
===========================

نسخة Flutter/Dart جاهزة للبناء على GitHub Actions.

المضاف في هذه النسخة:
- تطبيق صوتيات فقط بدون YouTube لتقليل الحجم.
- كروت أقسام بصور من Archive.org.
- أقسام المنشاوي من أرشيف الإنترنت.
- تحميل كسول: التطبيق يفتح بسرعة، وكل قسم يحمل تلاواته عند فتحه.
- Shimmer Loading بدل الدائرة التقليدية.
- شاشة خطأ احترافية عند انقطاع الإنترنت.
- مشغل صوت Mini Player أسفل التطبيق.
- مشغل كامل مع شريط تقدم.
- تشغيل في الخلفية وشاشة القفل عبر just_audio_background.
- مؤقت نوم: 5 / 15 / 30 / 60 دقيقة.
- خطوط عربية احترافية عبر Google Fonts: Noto Kufi Arabic للعناوين، IBM Plex Sans Arabic للنصوص، Tajawal للأزرار.
- GitHub Actions يبني APK مقسم حسب المعالج لتقليل الحجم.

طريقة الاستخدام على GitHub:
1. احذف أي ZIP قديم من الريبو.
2. ارفع هذا الـ ZIP فقط.
3. تأكد من وجود الملف:
   .github/workflows/build-apk.yml
4. افتح Actions.
5. شغل Build Minshawi Audio Pro APKs.
6. بعد النجاح نزّل Artifact باسم:
   minshawi-audio-pro-split-apks
7. جرّب على أندرويد 8 أولاً:
   minshawi-pro-armeabi-v7a.apk
   ولو لم يثبت جرّب:
   minshawi-pro-arm64-v8a.apk

ملاحظة:
أول مرة تفتح أي قسم لازم إنترنت. بعد التحميل، التطبيق يحفظ فهرس القسم ليفتح أسرع بعد ذلك.
