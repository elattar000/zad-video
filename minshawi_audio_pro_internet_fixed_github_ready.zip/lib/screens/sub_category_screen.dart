import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import '../controllers/archive_provider.dart';
import '../models/audio_model.dart';
import '../models/category_model.dart';
import '../utils/theme_constants.dart';
import '../widgets/archive_error_box.dart';
import '../widgets/audio_tile.dart';

class SubCategoryScreen extends StatefulWidget {
  final CategoryModel category;

  const SubCategoryScreen({super.key, required this.category});

  @override
  State<SubCategoryScreen> createState() => _SubCategoryScreenState();
}

class _SubCategoryScreenState extends State<SubCategoryScreen> {
  String _query = '';

  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<ArchiveProvider>().fetchCategory(widget.category.id));
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ArchiveProvider>();
    final List<AudioModel> source = provider.getAudiosByCategory(widget.category.id);
    final isLoading = provider.isLoadingCategory(widget.category.id);
    final error = provider.errorForCategory(widget.category.id);
    final q = _query.trim().toLowerCase();
    final audios = q.isEmpty
        ? source
        : source.where((a) => a.title.toLowerCase().contains(q) || a.fileName.toLowerCase().contains(q)).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.category.title),
        actions: [
          IconButton(
            tooltip: 'تحديث القسم',
            onPressed: () => provider.fetchCategory(widget.category.id, force: true),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: AppTheme.primaryColor,
        onRefresh: () => provider.fetchCategory(widget.category.id, force: true),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 22),
          children: [
            _CategoryBanner(category: widget.category, count: source.length),
            const SizedBox(height: 16),
            TextField(
              onChanged: (value) => setState(() => _query = value),
              decoration: const InputDecoration(
                hintText: 'ابحث داخل القسم...',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
            const SizedBox(height: 16),
            if (isLoading && source.isEmpty)
              const _AudioListShimmer()
            else if (error != null && source.isEmpty)
              ArchiveErrorBox(
                message: error,
                onRetry: () => provider.fetchCategory(widget.category.id, force: true),
              )
            else if (audios.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 80),
                child: Center(child: Text('لا توجد تلاوات مطابقة للبحث')),
              )
            else
              ...audios.map((audio) => AudioTile(audio: audio)),
          ],
        ),
      ),
    );
  }
}

class _CategoryBanner extends StatelessWidget {
  final CategoryModel category;
  final int count;

  const _CategoryBanner({required this.category, required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppTheme.primaryColor.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.06),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: CachedNetworkImage(
              imageUrl: category.imageUrl,
              width: 92,
              height: 92,
              fit: BoxFit.cover,
              placeholder: (_, __) => Shimmer.fromColors(
                baseColor: Colors.grey.shade300,
                highlightColor: Colors.grey.shade100,
                child: Container(width: 92, height: 92, color: Colors.white),
              ),
              errorWidget: (_, __, ___) => Container(
                width: 92,
                height: 92,
                color: AppTheme.secondaryColor,
                child: Icon(category.icon, color: AppTheme.primaryColor),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(category.title, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 20)),
                const SizedBox(height: 6),
                Text(category.subtitle, style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 10),
                Text(
                  count > 0 ? '$count تلاوة محملة' : 'سيتم تحميل التلاوات من الأرشيف الآن',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(color: AppTheme.primaryColor),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AudioListShimmer extends StatelessWidget {
  const _AudioListShimmer();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(8, (index) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Shimmer.fromColors(
            baseColor: Colors.grey.shade300,
            highlightColor: Colors.grey.shade100,
            child: Container(
              height: 76,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
        );
      }),
    );
  }
}
