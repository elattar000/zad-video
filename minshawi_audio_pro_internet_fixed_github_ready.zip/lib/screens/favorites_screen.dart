import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/archive_provider.dart';
import '../utils/theme_constants.dart';
import '../widgets/audio_tile.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ArchiveProvider>();
    final favorites = provider.favoriteAudios;

    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: favorites.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(26),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.favorite_border_rounded, size: 58, color: AppTheme.primaryColor),
                    const SizedBox(height: 14),
                    Text('لا توجد تلاوات مفضلة بعد', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 8),
                    Text(
                      'افتح أي قسم وشغّل التلاوة، ثم اضغط القلب لإضافتها هنا.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: favorites.length,
              itemBuilder: (context, index) => AudioTile(audio: favorites[index]),
            ),
    );
  }
}
