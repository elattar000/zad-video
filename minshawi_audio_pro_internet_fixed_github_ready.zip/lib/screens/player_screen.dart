import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/archive_provider.dart';
import '../controllers/audio_player_provider.dart';
import '../utils/theme_constants.dart';

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final playerProvider = context.watch<AudioPlayerProvider>();
    final archive = context.watch<ArchiveProvider>();
    final audio = playerProvider.currentAudio;

    if (audio == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('المشغل')),
        body: const Center(child: Text('لا توجد تلاوة قيد التشغيل')),
      );
    }

    final isFav = archive.isFavorite(audio);

    return Scaffold(
      appBar: AppBar(
        title: const Text('مشغل الصوت'),
        actions: [
          IconButton(
            tooltip: 'مؤقت النوم',
            onPressed: () => _showSleepTimerSheet(context),
            icon: Icon(playerProvider.hasSleepTimer ? Icons.bedtime_rounded : Icons.bedtime_outlined),
            color: playerProvider.hasSleepTimer ? AppTheme.gold : null,
          ),
          IconButton(
            tooltip: 'المفضلة',
            onPressed: () => archive.toggleFavorite(audio),
            icon: Icon(isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded),
            color: isFav ? Colors.redAccent : null,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 16),
            Container(
              width: 230,
              height: 230,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(46),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primaryColor.withOpacity(0.24),
                    blurRadius: 34,
                    offset: const Offset(0, 18),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(46),
                child: CachedNetworkImage(
                  imageUrl: audio.imageUrl,
                  fit: BoxFit.cover,
                  errorWidget: (_, __, ___) => Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [AppTheme.primaryColor, AppTheme.deepTeal],
                      ),
                    ),
                    child: const Icon(Icons.mic_external_on_rounded, size: 92, color: Colors.white),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
            Text(
              audio.title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineMedium,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),
            Text(
              audio.sizeLabel.isEmpty ? 'الشيخ محمد صديق المنشاوي' : audio.sizeLabel,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            if (playerProvider.hasSleepTimer) ...[
              const SizedBox(height: 8),
              Text(
                'مؤقت النوم مفعل',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(color: AppTheme.gold),
              ),
            ],
            const Spacer(),
            StreamBuilder<Duration>(
              stream: playerProvider.player.positionStream,
              builder: (context, snapshot) {
                final position = snapshot.data ?? Duration.zero;
                final duration = playerProvider.player.duration ?? Duration.zero;
                return ProgressBar(
                  progress: position,
                  total: duration,
                  onSeek: playerProvider.seek,
                  progressBarColor: AppTheme.primaryColor,
                  baseBarColor: AppTheme.secondaryColor,
                  thumbColor: AppTheme.primaryColor,
                  timeLabelTextStyle: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.bold),
                );
              },
            ),
            const SizedBox(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton.filledTonal(
                  onPressed: () {
                    final pos = playerProvider.player.position - const Duration(seconds: 10);
                    playerProvider.seek(pos < Duration.zero ? Duration.zero : pos);
                  },
                  icon: const Icon(Icons.replay_10_rounded),
                ),
                const SizedBox(width: 20),
                IconButton.filled(
                  onPressed: playerProvider.pauseOrResume,
                  style: IconButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    fixedSize: const Size(76, 76),
                  ),
                  icon: playerProvider.isBuffering
                      ? const SizedBox(
                          width: 30,
                          height: 30,
                          child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white),
                        )
                      : Icon(playerProvider.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 44),
                ),
                const SizedBox(width: 20),
                IconButton.filledTonal(
                  onPressed: () {
                    final pos = playerProvider.player.position + const Duration(seconds: 10);
                    playerProvider.seek(pos);
                  },
                  icon: const Icon(Icons.forward_10_rounded),
                ),
              ],
            ),
            const SizedBox(height: 28),
          ],
        ),
      ),
    );
  }

  void _showSleepTimerSheet(BuildContext context) {
    final provider = context.read<AudioPlayerProvider>();
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 26),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مؤقت النوم', style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 8),
              Text('اختار مدة وبعدها الصوت يقف تلقائيًا.', style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 18),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  _TimerChip(minutes: 5, provider: provider),
                  _TimerChip(minutes: 15, provider: provider),
                  _TimerChip(minutes: 30, provider: provider),
                  _TimerChip(minutes: 60, provider: provider),
                  ActionChip(
                    avatar: const Icon(Icons.close_rounded, size: 18),
                    label: const Text('إلغاء المؤقت'),
                    onPressed: () {
                      provider.cancelSleepTimer();
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _TimerChip extends StatelessWidget {
  final int minutes;
  final AudioPlayerProvider provider;

  const _TimerChip({required this.minutes, required this.provider});

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      avatar: const Icon(Icons.timer_rounded, size: 18),
      label: Text('$minutes دقيقة'),
      onPressed: () {
        provider.setSleepTimer(minutes);
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تم ضبط مؤقت النوم على $minutes دقيقة')),
        );
      },
    );
  }
}
