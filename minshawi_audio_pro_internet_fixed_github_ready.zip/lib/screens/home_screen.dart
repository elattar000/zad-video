import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/archive_provider.dart';
import '../utils/theme_constants.dart';
import '../widgets/category_card.dart';
import '../widgets/shimmer_category_grid.dart';
import 'search_screen.dart';
import 'sub_category_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<ArchiveProvider>().prepareFastStart());
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ArchiveProvider>();

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: AppTheme.primaryColor,
          onRefresh: () => provider.fetchAllCategories(force: true),
          child: CustomScrollView(
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    const _TopIdentity(),
                    const SizedBox(height: 22),
                    _SearchBox(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const SearchScreen(autoLoad: true)),
                      ),
                    ),
                    const SizedBox(height: 22),
                    const _HeroBanner(),
                    const SizedBox(height: 28),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('الأقسام الرئيسية', style: Theme.of(context).textTheme.headlineMedium),
                        Text(
                          '${provider.categories.length} أقسام',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppTheme.primaryColor),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    if (provider.isPreparing)
                      const ShimmerCategoryGrid(),
                  ]),
                ),
              ),
              if (!provider.isPreparing)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final category = provider.categories[index];
                        final count = provider.countForCategory(category.id);
                        final isLoading = provider.isLoadingCategory(category.id);
                        return CategoryCard(
                          category: category,
                          count: count,
                          isLoading: isLoading,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => SubCategoryScreen(category: category)),
                          ),
                        );
                      },
                      childCount: provider.categories.length,
                    ),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                      childAspectRatio: 0.78,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TopIdentity extends StatelessWidget {
  const _TopIdentity();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            color: AppTheme.primaryColor,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: AppTheme.primaryColor.withOpacity(0.22),
                blurRadius: 24,
                offset: const Offset(0, 12),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(13),
            child: Image.asset('assets/images/logo.png'),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('موسوعة المنشاوي', style: Theme.of(context).textTheme.displayLarge?.copyWith(fontSize: 25)),
              const SizedBox(height: 3),
              Text(
                'تلاوات نادرة ومصاحف كاملة من Archive.org',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppTheme.mutedText),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _SearchBox extends StatelessWidget {
  final VoidCallback onTap;
  const _SearchBox({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(26),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: Colors.black.withOpacity(0.035)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.035),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.search_rounded, color: AppTheme.textColor, size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'ابحث عن سورة أو تلاوة...',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppTheme.mutedText, fontSize: 17),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroBanner extends StatelessWidget {
  const _HeroBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFF10C7A8), Color(0xFF008C95), Color(0xFF006C73)],
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.22),
            blurRadius: 26,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            left: -6,
            top: -10,
            child: Icon(Icons.graphic_eq_rounded, size: 95, color: Colors.white.withOpacity(0.10)),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'استمع للشيخ محمد صديق المنشاوي',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white, fontSize: 21),
              ),
              const SizedBox(height: 8),
              Text(
                'الأقسام تظهر بسرعة، والتلاوات تتحمل عند فتح القسم فقط عشان التطبيق يبقى خفيف وسريع.',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.white.withOpacity(0.92)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
