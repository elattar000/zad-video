import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/archive_provider.dart';
import '../utils/theme_constants.dart';
import '../widgets/audio_tile.dart';

class SearchScreen extends StatefulWidget {
  final bool autoLoad;
  const SearchScreen({super.key, this.autoLoad = false});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String _query = '';
  bool _startedAutoLoad = false;

  @override
  void initState() {
    super.initState();
    if (widget.autoLoad) {
      Future.microtask(() {
        _startedAutoLoad = true;
        context.read<ArchiveProvider>().fetchAllCategories();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ArchiveProvider>();
    final results = provider.search(_query);
    final anyLoading = provider.categories.any((c) => provider.isLoadingCategory(c.id));
    final hasAny = provider.allAudios.isNotEmpty;

    return Scaffold(
      appBar: AppBar(title: const Text('البحث في التلاوات')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              autofocus: widget.autoLoad,
              onChanged: (value) => setState(() => _query = value),
              decoration: const InputDecoration(
                hintText: 'ابحث باسم السورة أو التلاوة...',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
          ),
          if (!hasAny && !_startedAutoLoad)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ElevatedButton.icon(
                onPressed: () {
                  setState(() => _startedAutoLoad = true);
                  provider.fetchAllCategories();
                },
                icon: const Icon(Icons.cloud_download_rounded),
                label: const Text('تحميل فهرس الأرشيف للبحث'),
              ),
            ),
          if (anyLoading)
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 4, 16, 10),
              child: LinearProgressIndicator(color: AppTheme.primaryColor),
            ),
          Expanded(
            child: results.isEmpty
                ? Center(
                    child: Text(
                      hasAny ? 'لا توجد نتائج' : 'حمّل الفهرس أولاً أو افتح أي قسم من الرئيسية',
                      textAlign: TextAlign.center,
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
                    itemCount: results.length,
                    itemBuilder: (context, index) => AudioTile(audio: results[index]),
                  ),
          ),
        ],
      ),
    );
  }
}
