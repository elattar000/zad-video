import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color primaryColor = Color(0xFF00A7B3);
  static const Color deepTeal = Color(0xFF007E86);
  static const Color secondaryColor = Color(0xFFE8F6F7);
  static const Color softBackground = Color(0xFFF5FBFB);
  static const Color cardColor = Color(0xFFFFFFFF);
  static const Color textColor = Color(0xFF263238);
  static const Color mutedText = Color(0xFF738487);
  static const Color gold = Color(0xFFD5A84C);

  static ThemeData get lightTheme {
    final base = ThemeData(
      useMaterial3: true,
      primaryColor: primaryColor,
      scaffoldBackgroundColor: softBackground,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        primary: primaryColor,
        secondary: gold,
        surface: cardColor,
      ),
    );

    return base.copyWith(
      textTheme: base.textTheme.copyWith(
        displayLarge: GoogleFonts.notoKufiArabic(
          color: textColor,
          fontWeight: FontWeight.w900,
          fontSize: 30,
          height: 1.25,
          letterSpacing: -0.7,
        ),
        headlineMedium: GoogleFonts.notoKufiArabic(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 23,
          height: 1.3,
          letterSpacing: -0.4,
        ),
        titleLarge: GoogleFonts.notoKufiArabic(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 18,
          height: 1.35,
        ),
        titleMedium: GoogleFonts.tajawal(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 16,
          height: 1.35,
        ),
        bodyLarge: GoogleFonts.ibmPlexSansArabic(
          color: textColor,
          fontWeight: FontWeight.w500,
          fontSize: 16,
          height: 1.55,
        ),
        bodyMedium: GoogleFonts.ibmPlexSansArabic(
          color: mutedText,
          fontWeight: FontWeight.w500,
          fontSize: 14,
          height: 1.5,
        ),
        bodySmall: GoogleFonts.ibmPlexSansArabic(
          color: mutedText,
          fontWeight: FontWeight.w500,
          fontSize: 12.5,
          height: 1.45,
        ),
        labelLarge: GoogleFonts.tajawal(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 15,
        ),
        labelMedium: GoogleFonts.tajawal(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 13,
        ),
      ),
      appBarTheme: AppBarTheme(
        centerTitle: true,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: softBackground,
        foregroundColor: textColor,
        titleTextStyle: GoogleFonts.notoKufiArabic(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 19,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Colors.white,
        indicatorColor: secondaryColor,
        elevation: 12,
        height: 74,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return GoogleFonts.tajawal(
            color: selected ? primaryColor : mutedText,
            fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
            fontSize: 12.5,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return IconThemeData(
            color: selected ? primaryColor : mutedText,
            size: selected ? 28 : 24,
          );
        }),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        hintStyle: GoogleFonts.ibmPlexSansArabic(color: mutedText, fontWeight: FontWeight.w500),
        labelStyle: GoogleFonts.ibmPlexSansArabic(color: mutedText),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(22),
          borderSide: const BorderSide(color: primaryColor, width: 1.8),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 54),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          textStyle: GoogleFonts.tajawal(fontSize: 17, fontWeight: FontWeight.w800),
        ),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shadowColor: primaryColor.withOpacity(0.08),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        surfaceTintColor: Colors.white,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        contentTextStyle: GoogleFonts.tajawal(fontWeight: FontWeight.w700),
      ),
    );
  }
}
