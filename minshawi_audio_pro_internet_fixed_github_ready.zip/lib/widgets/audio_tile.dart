import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/archive_provider.dart';
import '../controllers/audio_player_provider.dart';
import '../models/audio_model.dart';
import '../utils/theme_constants.dart';

class AudioTile extends StatelessWidget {
  final AudioModel audio;

  const AudioTile({super.key, required this.audio});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<AudioPlayerProvider>();
    final archive = context.watch<ArchiveProvider>();
    final isCurrent = player.currentAudio?.url == audio.url;
    final isPlaying = isCurrent && player.isPlaying;
    final isFav = archive.isFavorite(audio);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        leading: Stack(
          alignment: Alignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: CachedNetworkImage(
                imageUrl: audio.imageUrl,
                width: 52,
                height: 52,
                fit: BoxFit.cover,
                errorWidget: (_, __, ___) => Container(
                  width: 52,
                  height: 52,
                  color: AppTheme.secondaryColor,
                ),
              ),
            ),
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(isCurrent ? 0.34 : 0.22),
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            player.isBuffering && isCurrent
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                  )
                : Icon(isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: Colors.white, size: 30),
          ],
        ),
        title: Text(
          audio.title,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: Theme.of(context).textTheme.titleMedium,
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(audio.sizeLabel.isEmpty ? 'اضغط للاستماع' : 'اضغط للاستماع • ${audio.sizeLabel}'),
        ),
        trailing: IconButton(
          onPressed: () => archive.toggleFavorite(audio),
          icon: Icon(isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded),
          color: isFav ? Colors.redAccent : AppTheme.mutedText,
        ),
        onTap: () async {
          try {
            await context.read<AudioPlayerProvider>().playAudio(audio);
          } catch (_) {
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('تعذر تشغيل الصوت الآن')),
            );
          }
        },
      ),
    );
  }
}
