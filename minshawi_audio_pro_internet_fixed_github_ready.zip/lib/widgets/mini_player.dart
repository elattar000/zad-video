import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/audio_player_provider.dart';
import '../screens/player_screen.dart';
import '../utils/theme_constants.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final audioProvider = context.watch<AudioPlayerProvider>();
    final current = audioProvider.currentAudio;
    if (current == null) return const SizedBox.shrink();

    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlayerScreen())),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        decoration: const BoxDecoration(
          color: AppTheme.primaryColor,
          borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
          boxShadow: [
            BoxShadow(
              color: Color(0x3300A7B3),
              blurRadius: 22,
              offset: Offset(0, -10),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: CachedNetworkImage(
                    imageUrl: current.imageUrl,
                    width: 48,
                    height: 48,
                    fit: BoxFit.cover,
                    errorWidget: (_, __, ___) => Container(
                      width: 48,
                      height: 48,
                      color: Colors.white.withOpacity(0.18),
                      child: const Icon(Icons.mic_external_on_rounded, color: Colors.white),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        current.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Colors.white),
                      ),
                      Text(
                        audioProvider.hasSleepTimer ? 'مؤقت النوم مفعل' : 'الشيخ محمد صديق المنشاوي',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white.withOpacity(0.78)),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: audioProvider.pauseOrResume,
                  icon: audioProvider.isBuffering
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                        )
                      : Icon(
                          audioProvider.isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded,
                          color: Colors.white,
                          size: 40,
                        ),
                ),
              ],
            ),
            const SizedBox(height: 3),
            StreamBuilder<Duration>(
              stream: audioProvider.player.positionStream,
              builder: (context, snapshot) {
                final position = snapshot.data ?? Duration.zero;
                final duration = audioProvider.player.duration ?? Duration.zero;
                return ProgressBar(
                  progress: position,
                  total: duration,
                  onSeek: audioProvider.seek,
                  barHeight: 3,
                  thumbRadius: 5,
                  timeLabelLocation: TimeLabelLocation.none,
                  progressBarColor: Colors.white,
                  baseBarColor: Colors.white.withOpacity(0.24),
                  thumbColor: Colors.white,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
