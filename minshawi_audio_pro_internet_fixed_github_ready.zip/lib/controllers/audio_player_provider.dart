import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import '../models/audio_model.dart';

class AudioPlayerProvider with ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();
  AudioModel? _currentAudio;
  bool _isPlaying = false;
  bool _isBuffering = false;
  Timer? _sleepTimer;
  DateTime? _sleepTimerEndsAt;

  AudioPlayer get player => _player;
  AudioModel? get currentAudio => _currentAudio;
  bool get isPlaying => _isPlaying;
  bool get isBuffering => _isBuffering;
  bool get hasSleepTimer => _sleepTimer != null;
  DateTime? get sleepTimerEndsAt => _sleepTimerEndsAt;

  AudioPlayerProvider() {
    _player.playerStateStream.listen((state) {
      _isPlaying = state.playing;
      _isBuffering = state.processingState == ProcessingState.loading ||
          state.processingState == ProcessingState.buffering;
      notifyListeners();
    });
  }

  Future<void> playAudio(AudioModel audio) async {
    try {
      if (_currentAudio?.url == audio.url) {
        if (_player.playing) {
          await _player.pause();
        } else {
          await _player.play();
        }
        return;
      }

      _currentAudio = audio;
      notifyListeners();
      final source = AudioSource.uri(
        Uri.parse(audio.url),
        tag: MediaItem(
          id: audio.id,
          title: audio.title,
          artist: 'الشيخ محمد صديق المنشاوي',
          album: 'موسوعة المنشاوي الصوتية',
          artUri: Uri.parse(audio.imageUrl),
        ),
      );
      await _player.setAudioSource(source);
      await _player.play();
    } catch (e) {
      debugPrint('Audio play error: $e');
      rethrow;
    }
  }

  Future<void> pauseOrResume() async {
    if (_currentAudio == null) return;
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
  }

  Future<void> seek(Duration position) => _player.seek(position);

  void setSleepTimer(int minutes) {
    _sleepTimer?.cancel();
    _sleepTimerEndsAt = DateTime.now().add(Duration(minutes: minutes));
    _sleepTimer = Timer(Duration(minutes: minutes), () async {
      await _player.pause();
      _sleepTimer = null;
      _sleepTimerEndsAt = null;
      notifyListeners();
    });
    notifyListeners();
  }

  void cancelSleepTimer() {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    _sleepTimerEndsAt = null;
    notifyListeners();
  }

  Future<void> stop() async {
    await _player.stop();
    _currentAudio = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _player.dispose();
    _sleepTimer?.cancel();
    super.dispose();
  }
}
