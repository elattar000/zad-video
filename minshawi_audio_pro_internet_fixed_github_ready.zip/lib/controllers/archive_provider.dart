import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/audio_model.dart';
import '../models/category_model.dart';

class ArchiveProvider with ChangeNotifier {
  static const String _favoriteKey = 'favorite_audio_urls_v4';
  static const String _cachePrefix = 'cached_minshawi_category_v4_';

  final List<CategoryModel> categories = const [
    CategoryModel(
      id: 'murattal_radio',
      title: 'المصحف المرتل',
      subtitle: 'نسخة الإذاعة المصرية - تحميل مباشر من Archive.org',
      archiveIdentifier: 'alminshawi-radio-128kb-high-quality',
      fallbackIdentifiers: [
        'muhammad-siddiq-al-minshawi',
        'al-minshawi_202204',
        'MuhammadSiddiqAl-Minshawi_201611',
      ],
      imageUrl: 'https://archive.org/services/img/alminshawi-radio-128kb-high-quality',
      icon: Icons.menu_book_rounded,
    ),
    CategoryModel(
      id: 'murattal_cairo',
      title: 'مرتل صوت القاهرة',
      subtitle: 'تسجيلات مرتلة مقسمة للاستماع السريع',
      archiveIdentifier: '128------kb--mp3--quran--309---part--alminshawy--moratal---by--cairosound',
      fallbackIdentifiers: [
        'alminshawi-radio-128kb-high-quality',
        'al-minshawi_202204',
      ],
      imageUrl: 'https://archive.org/services/img/128------kb--mp3--quran--309---part--alminshawy--moratal---by--cairosound',
      icon: Icons.headphones_rounded,
    ),
    CategoryModel(
      id: 'complete',
      title: 'مصحف كامل',
      subtitle: 'ختمة كاملة مرتبة من الأرشيف',
      archiveIdentifier: 'al-minshawi_202204',
      fallbackIdentifiers: [
        'muhammad-siddiq-al-minshawi',
        'MuhammadSiddiqAl-Minshawi_201611',
        'lifeways11_gmail_001_20180201_0039',
      ],
      imageUrl: 'https://archive.org/services/img/al-minshawi_202204',
      icon: Icons.library_music_rounded,
    ),
    CategoryModel(
      id: 'mujawwad',
      title: 'المصحف المجود',
      subtitle: 'تلاوات مجودة ومحافل طويلة',
      archiveIdentifier: 'al-minshawi-mujawad',
      fallbackIdentifiers: [
        'Muhammad-SiddiqAl-Minshawi-Mujawwad',
        'Al-Minshawy_Muratal_Quran',
        'alminshawi-radio-128kb-high-quality',
      ],
      imageUrl: 'https://archive.org/services/img/al-minshawi-mujawad',
      icon: Icons.graphic_eq_rounded,
    ),
    CategoryModel(
      id: 'rare',
      title: 'تلاوات نادرة',
      subtitle: 'محافل وتسجيلات مختارة من الأرشيف',
      archiveIdentifier: 'Al-Minshawy_Muratal_Quran',
      fallbackIdentifiers: [
        'al-minshawi_202204',
        'MuhammadSiddiqAl-Minshawi_201611',
        'alminshawi-radio-128kb-high-quality',
      ],
      imageUrl: 'https://archive.org/services/img/Al-Minshawy_Muratal_Quran',
      icon: Icons.mic_external_on_rounded,
    ),
    CategoryModel(
      id: 'teacher',
      title: 'المصحف المعلم',
      subtitle: 'تلاوات تعليمية وترديد للأطفال',
      archiveIdentifier: '128--kb----alminshawy-teacher---repeat---kids---quran---full----30----part---a',
      fallbackIdentifiers: [
        '128_kb---mp3------------quran----6236---ayaat-----__verse--by---verse----_-by-',
        'alminshawi-radio-128kb-high-quality',
      ],
      imageUrl: 'https://archive.org/services/img/128--kb----alminshawy-teacher---repeat---kids---quran---full----30----part---a',
      icon: Icons.school_rounded,
    ),
  ];

  final Map<String, List<AudioModel>> _audiosByCategory = {};
  final Map<String, bool> _loadingByCategory = {};
  final Map<String, String?> _errorsByCategory = {};
  final Set<String> _favoriteUrls = <String>{};

  bool favoritesLoaded = false;
  bool isPreparing = false;
  bool hasError = false;
  String? homeErrorMessage;

  List<AudioModel> get allAudios {
    final all = _audiosByCategory.values.expand((items) => items).toList();
    all.sort((a, b) => a.title.compareTo(b.title));
    return List.unmodifiable(all);
  }

  Set<String> get favoriteUrls => Set.unmodifiable(_favoriteUrls);

  Future<void> prepareFastStart() async {
    // فتح التطبيق لا يعتمد على الإنترنت: نحمّل الكاش والمفضلة فقط.
    // الأقسام نفسها تظهر دائمًا، وأي مشكلة إنترنت تظهر داخل القسم فقط.
    isPreparing = true;
    hasError = false;
    homeErrorMessage = null;
    notifyListeners();
    try {
      await _loadFavorites();
      for (final category in categories) {
        await _loadCachedCategory(category.id);
      }
    } catch (e) {
      debugPrint('Fast start cache error: $e');
    }
    isPreparing = false;
    hasError = false;
    homeErrorMessage = null;
    notifyListeners();
  }

  Future<void> fetchArchiveData() => fetchAllCategories(force: true);

  bool isLoadingCategory(String categoryId) => _loadingByCategory[categoryId] ?? false;
  String? errorForCategory(String categoryId) => _errorsByCategory[categoryId];

  List<AudioModel> getAudiosByCategory(String categoryId) {
    return List.unmodifiable(_audiosByCategory[categoryId] ?? const <AudioModel>[]);
  }

  int countForCategory(String categoryId) => _audiosByCategory[categoryId]?.length ?? 0;

  CategoryModel? categoryById(String categoryId) {
    try {
      return categories.firstWhere((category) => category.id == categoryId);
    } catch (_) {
      return null;
    }
  }

  Future<void> fetchCategory(String categoryId, {bool force = false}) async {
    final category = categoryById(categoryId);
    if (category == null) return;
    if (isLoadingCategory(categoryId)) return;
    if (!force && (_audiosByCategory[categoryId]?.isNotEmpty ?? false)) return;

    _loadingByCategory[categoryId] = true;
    _errorsByCategory[categoryId] = null;
    notifyListeners();

    final parsed = <AudioModel>[];
    final tried = <String>[];

    try {
      for (final identifier in category.allIdentifiers) {
        tried.add(identifier);
        try {
          final url = Uri.parse('https://archive.org/metadata/$identifier');
          final response = await http.get(
            url,
            headers: const {
              'Accept': 'application/json,text/plain,*/*',
              'User-Agent': 'MinshawiAudioApp/1.0 Flutter Android',
            },
          ).timeout(const Duration(seconds: 18));

          if (response.statusCode != 200) {
            debugPrint('Archive metadata [$identifier] status ${response.statusCode}');
            continue;
          }

          final data = json.decode(response.body) as Map<String, dynamic>;
          final files = (data['files'] as List?) ?? const [];
          for (final file in files) {
            if (file is! Map<String, dynamic>) continue;
            final name = (file['name'] ?? '').toString();
            final lower = name.toLowerCase();
            if (!lower.endsWith('.mp3')) continue;
            if (lower.contains('/__macosx/') || lower.contains('__macosx')) continue;
            if (lower.contains('_vbr_mp3.zip') || lower.contains('.zip')) continue;
            parsed.add(AudioModel.fromArchiveJson(
              file,
              identifier,
              category.id,
              'https://archive.org/services/img/$identifier',
            ));
          }

          if (parsed.isNotEmpty) break;
        } catch (e) {
          debugPrint('Archive try failed [$identifier]: $e');
        }
      }

      if (parsed.isEmpty) {
        throw Exception('No mp3 files found. Tried: ${tried.join(', ')}');
      }

      parsed.sort((a, b) => _naturalSortKey(a.fileName).compareTo(_naturalSortKey(b.fileName)));
      _audiosByCategory[categoryId] = parsed;
      _errorsByCategory[categoryId] = null;
      await _saveCachedCategory(categoryId);
    } catch (e) {
      final hasOldCache = _audiosByCategory[categoryId]?.isNotEmpty ?? false;
      if (!hasOldCache) {
        _errorsByCategory[categoryId] = 'مش قادر أوصل للأرشيف دلوقتي. اتأكد من الإنترنت، ولو فاتح VPN اقفله، واضغط إعادة المحاولة.';
      }
      debugPrint('Archive category error [$categoryId] tried=$tried error=$e');
    }

    _loadingByCategory[categoryId] = false;
    notifyListeners();
  }

  Future<void> fetchAllCategories({bool force = false}) async {
    for (final category in categories) {
      await fetchCategory(category.id, force: force);
    }
  }

  List<AudioModel> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return allAudios;
    return allAudios.where((audio) {
      return audio.title.toLowerCase().contains(q) ||
          audio.fileName.toLowerCase().contains(q) ||
          audio.archiveIdentifier.toLowerCase().contains(q);
    }).toList();
  }

  List<AudioModel> get favoriteAudios {
    return allAudios.where((audio) => _favoriteUrls.contains(audio.url)).toList();
  }

  bool isFavorite(AudioModel audio) => _favoriteUrls.contains(audio.url);

  Future<void> toggleFavorite(AudioModel audio) async {
    if (_favoriteUrls.contains(audio.url)) {
      _favoriteUrls.remove(audio.url);
    } else {
      _favoriteUrls.add(audio.url);
    }
    notifyListeners();
    await _saveFavorites();
  }

  Future<void> _loadCachedCategory(String categoryId) async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getStringList('$_cachePrefix$categoryId') ?? const <String>[];
    if (cached.isNotEmpty) {
      _audiosByCategory[categoryId] = cached.map(AudioModel.fromJson).toList();
    }
  }

  Future<void> _saveCachedCategory(String categoryId) async {
    final prefs = await SharedPreferences.getInstance();
    final items = _audiosByCategory[categoryId] ?? const <AudioModel>[];
    await prefs.setStringList('$_cachePrefix$categoryId', items.map((audio) => audio.toJson()).toList());
  }

  Future<void> _loadFavorites() async {
    if (favoritesLoaded) return;
    final prefs = await SharedPreferences.getInstance();
    _favoriteUrls
      ..clear()
      ..addAll(prefs.getStringList(_favoriteKey) ?? const <String>[]);
    favoritesLoaded = true;
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_favoriteKey, _favoriteUrls.toList());
  }

  String _naturalSortKey(String input) {
    return input.toLowerCase().replaceAll(RegExp(r'[^0-9a-z\u0600-\u06ff]+'), ' ');
  }
}
