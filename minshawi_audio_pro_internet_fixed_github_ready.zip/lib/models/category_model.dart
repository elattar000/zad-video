import 'package:flutter/material.dart';

class CategoryModel {
  final String id;
  final String title;
  final String subtitle;
  final String archiveIdentifier;
  final List<String> fallbackIdentifiers;
  final String imageUrl;
  final IconData icon;

  const CategoryModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.archiveIdentifier,
    this.fallbackIdentifiers = const [],
    required this.imageUrl,
    required this.icon,
  });

  List<String> get allIdentifiers {
    final set = <String>{archiveIdentifier, ...fallbackIdentifiers};
    return set.where((e) => e.trim().isNotEmpty).toList(growable: false);
  }
}
