import 'dart:convert';

class AudioModel {
  final String id;
  final String title;
  final String fileName;
  final String url;
  final String size;
  final String categoryId;
  final String archiveIdentifier;
  final String imageUrl;

  const AudioModel({
    required this.id,
    required this.title,
    required this.fileName,
    required this.url,
    required this.size,
    required this.categoryId,
    required this.archiveIdentifier,
    required this.imageUrl,
  });

  String get sizeLabel {
    final bytes = int.tryParse(size);
    if (bytes == null || bytes <= 0) return '';
    final mb = bytes / (1024 * 1024);
    if (mb < 1) return '${(bytes / 1024).toStringAsFixed(0)} ك.ب';
    return '${mb.toStringAsFixed(1)} م.ب';
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'fileName': fileName,
      'url': url,
      'size': size,
      'categoryId': categoryId,
      'archiveIdentifier': archiveIdentifier,
      'imageUrl': imageUrl,
    };
  }

  String toJson() => json.encode(toMap());

  factory AudioModel.fromJson(String source) {
    return AudioModel.fromMap(json.decode(source) as Map<String, dynamic>);
  }

  factory AudioModel.fromMap(Map<String, dynamic> map) {
    final identifier = (map['archiveIdentifier'] ?? '').toString();
    return AudioModel(
      id: (map['id'] ?? '').toString(),
      title: (map['title'] ?? '').toString(),
      fileName: (map['fileName'] ?? '').toString(),
      url: (map['url'] ?? '').toString(),
      size: (map['size'] ?? '').toString(),
      categoryId: (map['categoryId'] ?? '').toString(),
      archiveIdentifier: identifier,
      imageUrl: (map['imageUrl'] ?? 'https://archive.org/services/img/$identifier').toString(),
    );
  }

  factory AudioModel.fromArchiveJson(
    Map<String, dynamic> json,
    String identifier,
    String categoryId,
    String imageUrl,
  ) {
    final rawName = (json['name'] ?? '').toString();
    final encodedName = rawName.split('/').map(Uri.encodeComponent).join('/');
    final title = _cleanTitle((json['title'] ?? rawName).toString());
    return AudioModel(
      id: '$identifier/$rawName',
      title: title,
      fileName: rawName,
      url: 'https://archive.org/download/$identifier/$encodedName',
      size: (json['size'] ?? '').toString(),
      categoryId: categoryId,
      archiveIdentifier: identifier,
      imageUrl: imageUrl,
    );
  }

  static String _cleanTitle(String input) {
    var value = input
        .replaceAll('.mp3', '')
        .replaceAll('.MP3', '')
        .replaceAll('_', ' ')
        .replaceAll('-', ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    value = value.replaceFirst(RegExp(r'^\d{1,4}\s*'), '');
    return value.isEmpty ? 'تلاوة صوتية' : value;
  }
}
