import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ZadApp());
}

class VideoItem {
  final String id;
  final String title;
  final String url;
  final String category;
  final int createdAt;

  const VideoItem({
    required this.id,
    required this.title,
    required this.url,
    required this.category,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'url': url,
        'category': category,
        'createdAt': createdAt,
      };

  factory VideoItem.fromJson(Map<String, dynamic> json) {
    return VideoItem(
      id: '${json['id'] ?? DateTime.now().millisecondsSinceEpoch}',
      title: '${json['title'] ?? ''}',
      url: '${json['url'] ?? ''}',
      category: '${json['category'] ?? 'الدورات الحالية'}',
      createdAt: int.tryParse('${json['createdAt'] ?? 0}') ?? 0,
    );
  }
}

class VideoStore {
  static const key = 'zad_videos_v1';

  static Future<List<VideoItem>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.trim().isEmpty) return seedVideos;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        final list = decoded
            .whereType<Map>()
            .map((e) => VideoItem.fromJson(Map<String, dynamic>.from(e)))
            .toList();
        list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        return list;
      }
    } catch (_) {}
    return seedVideos;
  }

  static Future<void> save(List<VideoItem> videos) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(videos.map((e) => e.toJson()).toList()));
  }

  static Future<void> add(VideoItem item) async {
    final videos = await load();
    videos.insert(0, item);
    await save(videos);
  }

  static Future<void> delete(String id) async {
    final videos = await load();
    videos.removeWhere((v) => v.id == id);
    await save(videos);
  }

  static Future<void> reset() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(key);
  }
}

const seedVideos = <VideoItem>[
  VideoItem(
    id: 'demo-1',
    title: 'درس تجريبي: مقدمة في التفسير',
    url: 'https://www.youtube.com/watch?v=ysz5S6PUM-U',
    category: 'القرآن وتفسيره',
    createdAt: 2,
  ),
  VideoItem(
    id: 'demo-2',
    title: 'درس تجريبي: السيرة والقصص',
    url: 'https://www.youtube.com/watch?v=ysz5S6PUM-U',
    category: 'السير والقصص',
    createdAt: 1,
  ),
];

const categories = [
  'الدورات الحالية',
  'القرآن وتفسيره',
  'السير والقصص',
  'التربوي الإيماني',
  'الملفات المتخصصة',
  'التلاوات القرآنية',
  'البرامج الدعوية',
];

class ZadApp extends StatelessWidget {
  const ZadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'زاد فيديو',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff00a889)),
        scaffoldBackgroundColor: const Color(0xfff6fbfb),
        fontFamily: 'Roboto',
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: ShellScreen(),
      ),
    );
  }
}

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key});

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int index = 0;
  List<VideoItem> videos = seedVideos;

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final list = await VideoStore.load();
    if (mounted) setState(() => videos = list);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      UserHome(videos: videos, onChanged: refresh),
      AdminLogin(onChanged: refresh),
      InfoPage(videosCount: videos.length),
    ];

    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'المستخدم'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings_rounded), label: 'الأدمن'),
          NavigationDestination(icon: Icon(Icons.info_outline_rounded), label: 'معلومات'),
        ],
      ),
    );
  }
}

class UserHome extends StatefulWidget {
  final List<VideoItem> videos;
  final VoidCallback onChanged;

  const UserHome({super.key, required this.videos, required this.onChanged});

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  String search = '';
  String selected = 'الكل';

  String? youtubeId(String url) {
    final uri = Uri.tryParse(url.trim());
    if (uri == null) return null;
    if (uri.host.contains('youtu.be') && uri.pathSegments.isNotEmpty) return uri.pathSegments.first;
    if (uri.host.contains('youtube.com')) return uri.queryParameters['v'];
    return null;
  }

  Future<void> openUrl(String url) async {
    final uri = Uri.tryParse(url.trim());
    if (uri == null) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final allCategories = ['الكل', ...categories];
    final list = widget.videos.where((v) {
      final s = search.trim();
      final bySearch = s.isEmpty || v.title.contains(s) || v.category.contains(s);
      final byCat = selected == 'الكل' || v.category == selected;
      return bySearch && byCat;
    }).toList();

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: () async => widget.onChanged(),
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 54,
                          height: 54,
                          decoration: BoxDecoration(
                            color: const Color(0xff00a889),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: const Icon(Icons.play_lesson_rounded, color: Colors.white, size: 30),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('زاد فيديو', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                              Text('تطبيق تجريبي Flutter/Dart', style: TextStyle(color: Colors.grey)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    TextField(
                      onChanged: (v) => setState(() => search = v),
                      decoration: InputDecoration(
                        hintText: 'ابحث عن دورة أو درس...',
                        prefixIcon: const Icon(Icons.search_rounded),
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xff10b981), Color(0xff0f766e)]),
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: const [BoxShadow(blurRadius: 18, color: Color(0x2200a889), offset: Offset(0, 8))],
                      ),
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('منصة فيديوهات تعليمية', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                          SizedBox(height: 7),
                          Text('أضف الفيديو من تبويب الأدمن، وهتلاقيه ظهر هنا فورًا.', style: TextStyle(color: Colors.white, fontSize: 14)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    const Text('التصنيفات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 10),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: allCategories.map((c) {
                          final active = selected == c;
                          return Padding(
                            padding: const EdgeInsetsDirectional.only(end: 8),
                            child: ChoiceChip(
                              label: Text(c),
                              selected: active,
                              onSelected: (_) => setState(() => selected = c),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text('الدروس (${list.length})', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  ],
                ),
              ),
            ),
            if (list.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: Center(child: Text('لا توجد فيديوهات مطابقة للبحث')),
              )
            else
              SliverList.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) {
                  final v = list[i];
                  final id = youtubeId(v.url);
                  final thumb = id == null ? null : 'https://img.youtube.com/vi/$id/hqdefault.jpg';
                  return Padding(
                    padding: EdgeInsets.fromLTRB(18, i == list.length - 1 ? 0 : 0, 18, i == list.length - 1 ? 18 : 0),
                    child: Container(
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: const [BoxShadow(blurRadius: 18, color: Color(0x11000000))]),
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        onTap: () => openUrl(v.url),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (thumb != null)
                              AspectRatio(
                                aspectRatio: 16 / 9,
                                child: Image.network(thumb, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xffe8f6f4), child: Icon(Icons.play_circle_fill_rounded, size: 55))),
                              )
                            else
                              Container(
                                height: 130,
                                color: const Color(0xffe8f6f4),
                                child: const Center(child: Icon(Icons.play_circle_fill_rounded, size: 55, color: Color(0xff00a889))),
                              ),
                            Padding(
                              padding: const EdgeInsets.all(14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(v.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                                  const SizedBox(height: 6),
                                  Row(
                                    children: [
                                      const Icon(Icons.category_outlined, size: 16, color: Color(0xff00a889)),
                                      const SizedBox(width: 5),
                                      Text(v.category, style: const TextStyle(color: Color(0xff00a889), fontWeight: FontWeight.bold)),
                                      const Spacer(),
                                      const Text('فتح الفيديو', style: TextStyle(color: Colors.grey)),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class AdminLogin extends StatefulWidget {
  final VoidCallback onChanged;
  const AdminLogin({super.key, required this.onChanged});

  @override
  State<AdminLogin> createState() => _AdminLoginState();
}

class _AdminLoginState extends State<AdminLogin> {
  bool loggedIn = false;
  final pass = TextEditingController();

  void check() {
    if (pass.text.trim() == '1234') {
      setState(() => loggedIn = true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('كلمة السر غير صحيحة')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loggedIn) return AdminPanel(onChanged: widget.onChanged);
    return SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), boxShadow: const [BoxShadow(blurRadius: 24, color: Color(0x14000000))]),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(color: const Color(0xff00a889), borderRadius: BorderRadius.circular(22)),
                  child: const Icon(Icons.admin_panel_settings_rounded, color: Colors.white, size: 40),
                ),
                const SizedBox(height: 15),
                const Text('لوحة إدارة الفيديوهات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text('كلمة السر الافتراضية: 1234', style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 18),
                TextField(
                  controller: pass,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: 'اكتب كلمة السر',
                    filled: true,
                    fillColor: const Color(0xfff2f7f7),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                  ),
                  onSubmitted: (_) => check(),
                ),
                const SizedBox(height: 16),
                SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: check, child: const Text('دخول الأدمن'))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AdminPanel extends StatefulWidget {
  final VoidCallback onChanged;
  const AdminPanel({super.key, required this.onChanged});

  @override
  State<AdminPanel> createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  final title = TextEditingController();
  final url = TextEditingController();
  String category = categories.first;
  List<VideoItem> videos = [];

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final list = await VideoStore.load();
    if (mounted) setState(() => videos = list);
  }

  bool validYoutube(String link) {
    final u = Uri.tryParse(link.trim());
    if (u == null) return false;
    return u.host.contains('youtube.com') || u.host.contains('youtu.be');
  }

  Future<void> addVideo() async {
    final t = title.text.trim();
    final link = url.text.trim();
    if (t.isEmpty || link.isEmpty) {
      message('اكتب عنوان الفيديو والرابط');
      return;
    }
    if (!validYoutube(link)) {
      message('حط رابط يوتيوب صحيح');
      return;
    }
    await VideoStore.add(VideoItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: t,
      url: link,
      category: category,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    ));
    title.clear();
    url.clear();
    await refresh();
    widget.onChanged();
    message('تمت الإضافة، ارجع لتبويب المستخدم هتلاقي الفيديو ظهر');
  }

  Future<void> removeVideo(String id) async {
    await VideoStore.delete(id);
    await refresh();
    widget.onChanged();
    message('تم حذف الفيديو');
  }

  Future<void> resetDemo() async {
    await VideoStore.reset();
    await refresh();
    widget.onChanged();
    message('رجعنا الفيديوهات التجريبية');
  }

  void message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Row(
            children: [
              const Expanded(child: Text('لوحة الأدمن', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
              IconButton(onPressed: resetDemo, icon: const Icon(Icons.restore_rounded), tooltip: 'استرجاع التجربة'),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: const [BoxShadow(blurRadius: 18, color: Color(0x11000000))]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('إضافة فيديو يوتيوب', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 14),
                TextField(
                  controller: title,
                  decoration: InputDecoration(
                    labelText: 'عنوان الفيديو',
                    filled: true,
                    fillColor: const Color(0xfff2f7f7),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: url,
                  keyboardType: TextInputType.url,
                  decoration: InputDecoration(
                    labelText: 'رابط يوتيوب',
                    hintText: 'https://youtube.com/watch?v=...',
                    filled: true,
                    fillColor: const Color(0xfff2f7f7),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: category,
                  items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) => setState(() => category = v ?? category),
                  decoration: InputDecoration(
                    labelText: 'التصنيف',
                    filled: true,
                    fillColor: const Color(0xfff2f7f7),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: FilledButton.icon(onPressed: addVideo, icon: const Icon(Icons.add_rounded), label: const Text('إضافة الفيديو')),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text('الفيديوهات الموجودة (${videos.length})', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          ...videos.map((v) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  title: Text(v.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(v.category),
                  leading: const Icon(Icons.play_circle_outline_rounded, color: Color(0xff00a889)),
                  trailing: IconButton(icon: const Icon(Icons.delete_outline_rounded, color: Colors.red), onPressed: () => removeVideo(v.id)),
                ),
              )),
        ],
      ),
    );
  }
}

class InfoPage extends StatelessWidget {
  final int videosCount;
  const InfoPage({super.key, required this.videosCount});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          const Text('معلومات النسخة', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          infoCard(
            icon: Icons.code_rounded,
            title: 'التقنية',
            body: 'هذا تطبيق Flutter/Dart حقيقي، وليس HTML وليس WebView.',
          ),
          infoCard(
            icon: Icons.android_rounded,
            title: 'Android 8',
            body: 'النسخة مناسبة للتجربة على Android 8، لأنها تبنى كتطبيق Android عادي من Flutter.',
          ),
          infoCard(
            icon: Icons.storage_rounded,
            title: 'طريقة الحفظ',
            body: 'الفيديوهات تحفظ داخل نفس الجهاز. لذلك الأدمن والمستخدم في نفس APK للتجربة السريعة.',
          ),
          infoCard(
            icon: Icons.cloud_sync_rounded,
            title: 'النسخة العامة للناس',
            body: 'لو عايز تضيف فيديو من جهازك ويظهر عند كل المستخدمين، لازم نربطها لاحقًا بـ Firebase أو سيرفر.',
          ),
          infoCard(
            icon: Icons.video_library_rounded,
            title: 'عدد الفيديوهات الحالي',
            body: '$videosCount فيديو',
          ),
        ],
      ),
    );
  }

  Widget infoCard({required IconData icon, required String title, required String body}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(blurRadius: 18, color: Color(0x11000000))]),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xff00a889)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                const SizedBox(height: 5),
                Text(body, style: const TextStyle(height: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
