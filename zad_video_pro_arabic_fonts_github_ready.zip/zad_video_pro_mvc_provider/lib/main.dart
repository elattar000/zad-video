import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'controllers/video_provider.dart';
import 'screens/home_screen.dart';
import 'theme/app_typography.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // السماح بجلب خطوط Google Fonts عند أول تشغيل ثم تخزينها في الكاش.
  // لم نضع ملفات خطوط داخل المشروع حتى يظل المشروع خفيفاً وقانونياً.
  GoogleFonts.config.allowRuntimeFetching = true;

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => VideoProvider()),
      ],
      child: const ZadVideoApp(),
    ),
  );
}

class ZadVideoApp extends StatelessWidget {
  const ZadVideoApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF009E78);
    final colorScheme = ColorScheme.fromSeed(
      seedColor: seed,
      primary: seed,
      secondary: const Color(0xFF006D77),
      tertiary: const Color(0xFF0A7C86),
      surface: const Color(0xFFF7FBF9),
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'زاد فيديو Pro',
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('ar', 'EG'), Locale('ar', 'AE')],
      locale: const Locale('ar', 'EG'),
      theme: ThemeData(
        colorScheme: colorScheme,
        textTheme: AppTypography.textTheme(colorScheme),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF4FAF7),
        appBarTheme: AppBarTheme(
          centerTitle: false,
          elevation: 0,
          scrolledUnderElevation: 0,
          backgroundColor: const Color(0xFFF4FAF7),
          foregroundColor: colorScheme.onSurface,
          titleTextStyle: AppTypography.appBarTitle(colorScheme),
        ),
        searchBarTheme: SearchBarThemeData(
          elevation: const WidgetStatePropertyAll(0),
          backgroundColor: const WidgetStatePropertyAll(Colors.white),
          hintStyle: WidgetStatePropertyAll(
            AppTypography.textTheme(colorScheme).bodyLarge?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
          ),
          textStyle: WidgetStatePropertyAll(
            AppTypography.textTheme(colorScheme).bodyLarge,
          ),
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: colorScheme.outlineVariant),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: colorScheme.outlineVariant),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: colorScheme.primary, width: 1.6),
          ),
          labelStyle: AppTypography.textTheme(colorScheme).bodyMedium,
          hintStyle: AppTypography.textTheme(colorScheme).bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            textStyle: AppTypography.textTheme(colorScheme).labelLarge,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            textStyle: AppTypography.textTheme(colorScheme).labelLarge,
          ),
        ),
        chipTheme: ChipThemeData(
          labelStyle: AppTypography.textTheme(colorScheme).labelMedium,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          side: BorderSide(color: colorScheme.outlineVariant),
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          surfaceTintColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          contentTextStyle: AppTypography.textTheme(colorScheme).bodyMedium?.copyWith(
                color: Colors.white,
              ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
