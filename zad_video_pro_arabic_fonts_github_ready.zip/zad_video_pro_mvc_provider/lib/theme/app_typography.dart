import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// نظام خطوط عربي احترافي بدون تضمين ملفات خطوط داخل المشروع.
///
/// العناوين: Noto Kufi Arabic
/// النصوص: IBM Plex Sans Arabic
/// الأزرار والوسوم: Tajawal
class AppTypography {
  const AppTypography._();

  static TextTheme textTheme(ColorScheme colors) {
    final base = ThemeData(brightness: Brightness.light).textTheme;
    final bodyTheme = GoogleFonts.ibmPlexSansArabicTextTheme(base);

    return bodyTheme.copyWith(
      displayLarge: GoogleFonts.notoKufiArabic(
        fontSize: 36,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.7,
        height: 1.25,
      ),
      displayMedium: GoogleFonts.notoKufiArabic(
        fontSize: 32,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.6,
        height: 1.25,
      ),
      displaySmall: GoogleFonts.notoKufiArabic(
        fontSize: 28,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.5,
        height: 1.25,
      ),
      headlineLarge: GoogleFonts.notoKufiArabic(
        fontSize: 25,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.4,
        height: 1.35,
      ),
      headlineMedium: GoogleFonts.notoKufiArabic(
        fontSize: 22,
        fontWeight: FontWeight.w800,
        letterSpacing: -0.25,
        height: 1.35,
      ),
      headlineSmall: GoogleFonts.notoKufiArabic(
        fontSize: 20,
        fontWeight: FontWeight.w800,
        height: 1.35,
      ),
      titleLarge: GoogleFonts.notoKufiArabic(
        fontSize: 18.5,
        fontWeight: FontWeight.w800,
        height: 1.45,
      ),
      titleMedium: GoogleFonts.ibmPlexSansArabic(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        height: 1.55,
      ),
      titleSmall: GoogleFonts.ibmPlexSansArabic(
        fontSize: 14.5,
        fontWeight: FontWeight.w700,
        height: 1.5,
      ),
      bodyLarge: GoogleFonts.ibmPlexSansArabic(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        height: 1.7,
      ),
      bodyMedium: GoogleFonts.ibmPlexSansArabic(
        fontSize: 14.5,
        fontWeight: FontWeight.w500,
        height: 1.65,
      ),
      bodySmall: GoogleFonts.ibmPlexSansArabic(
        fontSize: 12.8,
        fontWeight: FontWeight.w500,
        height: 1.55,
      ),
      labelLarge: GoogleFonts.tajawal(
        fontSize: 15.5,
        fontWeight: FontWeight.w700,
        height: 1.35,
      ),
      labelMedium: GoogleFonts.tajawal(
        fontSize: 13.5,
        fontWeight: FontWeight.w700,
        height: 1.3,
      ),
      labelSmall: GoogleFonts.tajawal(
        fontSize: 12,
        fontWeight: FontWeight.w700,
        height: 1.25,
      ),
    ).apply(
      bodyColor: colors.onSurface,
      displayColor: colors.onSurface,
    );
  }

  static TextStyle appBarTitle(ColorScheme colors) {
    return GoogleFonts.notoKufiArabic(
      fontSize: 19,
      fontWeight: FontWeight.w800,
      color: colors.onSurface,
      height: 1.35,
    );
  }

  static TextStyle brandTitle(Color color) {
    return GoogleFonts.notoKufiArabic(
      fontSize: 27,
      fontWeight: FontWeight.w900,
      color: color,
      letterSpacing: -0.6,
      height: 1.2,
    );
  }

  static TextStyle heroTitle() {
    return GoogleFonts.notoKufiArabic(
      color: Colors.white,
      fontSize: 25,
      fontWeight: FontWeight.w900,
      height: 1.35,
      letterSpacing: -0.4,
    );
  }

  static TextStyle heroSubtitle() {
    return GoogleFonts.ibmPlexSansArabic(
      color: Colors.white,
      fontSize: 15.5,
      fontWeight: FontWeight.w500,
      height: 1.7,
    );
  }
}
