import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/video_model.dart';

class VideoProvider extends ChangeNotifier {
  static const String _storageKey = 'videos';

  List<VideoModel> _videos = [];
  String _searchQuery = '';
  String _selectedCategory = 'الكل';

  List<VideoModel> get videos => List.unmodifiable(_videos);
  String get searchQuery => _searchQuery;
  String get selectedCategory => _selectedCategory;

  List<String> get categories {
    final custom = _videos.map((video) => video.category).where((c) => c.isNotEmpty).toSet().toList();
    final base = ['الكل', 'عام', 'تعليمي', 'ترفيهي', 'ديني'];
    return {...base, ...custom}.toList();
  }

  List<VideoModel> get filteredVideos {
    return _videos.where((video) {
      final matchesSearch = _searchQuery.trim().isEmpty ||
          video.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          video.description.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          video.category.toLowerCase().contains(_searchQuery.toLowerCase());

      final matchesCategory = _selectedCategory == 'الكل' || video.category == _selectedCategory;
      return matchesSearch && matchesCategory;
    }).toList();
  }

  VideoProvider() {
    loadVideos();
  }

  Future<void> loadVideos() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String>? savedVideos = prefs.getStringList(_storageKey);

    if (savedVideos != null) {
      _videos = savedVideos.map((v) => VideoModel.fromJson(v)).toList();
      notifyListeners();
      return;
    }

    _videos = [
      const VideoModel(
        id: 'demo-1',
        title: 'مثال: درس تجريبي من يوتيوب',
        url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        category: 'تعليمي',
        description: 'هذا فيديو تجريبي للتأكد من شكل الكارت والمشغل. يمكنك حذفه من لوحة الأدمن.',
      ),
    ];
    await _saveData();
    notifyListeners();
  }

  Future<void> addVideo(VideoModel video) async {
    _videos.insert(0, video);
    notifyListeners();
    await _saveData();
  }

  Future<void> deleteVideo(String id) async {
    _videos.removeWhere((video) => video.id == id);
    notifyListeners();
    await _saveData();
  }

  void updateSearch(String value) {
    _searchQuery = value;
    notifyListeners();
  }

  void updateCategory(String value) {
    _selectedCategory = value;
    notifyListeners();
  }

  Future<void> clearAll() async {
    _videos.clear();
    notifyListeners();
    await _saveData();
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> encodedVideos = _videos.map((v) => v.toJson()).toList();
    await prefs.setStringList(_storageKey, encodedVideos);
  }
}
