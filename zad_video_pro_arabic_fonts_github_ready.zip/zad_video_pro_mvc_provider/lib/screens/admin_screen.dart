import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../controllers/video_provider.dart';
import '../models/video_model.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _urlController = TextEditingController();
  final _descController = TextEditingController();
  String _selectedCategory = 'عام';

  @override
  void dispose() {
    _titleController.dispose();
    _urlController.dispose();
    _descController.dispose();
    super.dispose();
  }

  void _addVideo() {
    if (!_formKey.currentState!.validate()) return;

    final newVideo = VideoModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: _titleController.text.trim(),
      url: _urlController.text.trim(),
      category: _selectedCategory,
      description: _descController.text.trim(),
    );

    context.read<VideoProvider>().addVideo(newVideo);

    _titleController.clear();
    _urlController.clear();
    _descController.clear();
    FocusScope.of(context).unfocus();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم إضافة الفيديو بنجاح')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<VideoProvider>();
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('لوحة تحكم الأدمن')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16.0),
          children: [
            Card(
              elevation: 0,
              color: theme.colorScheme.primaryContainer.withOpacity(0.45),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'إضافة فيديو جديد',
                        style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _titleController,
                        decoration: const InputDecoration(
                          labelText: 'عنوان الفيديو',
                          prefixIcon: Icon(Icons.title_rounded),
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) => value == null || value.trim().isEmpty ? 'اكتب عنوان الفيديو' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _urlController,
                        keyboardType: TextInputType.url,
                        decoration: const InputDecoration(
                          labelText: 'رابط يوتيوب',
                          prefixIcon: Icon(Icons.link_rounded),
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          final text = value?.trim() ?? '';
                          if (text.isEmpty) return 'ضع رابط يوتيوب';
                          if (YoutubePlayer.convertUrlToId(text) == null) return 'الرابط ليس رابط يوتيوب صحيح';
                          return null;
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _descController,
                        minLines: 2,
                        maxLines: 4,
                        decoration: const InputDecoration(
                          labelText: 'وصف الفيديو',
                          prefixIcon: Icon(Icons.description_rounded),
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: _selectedCategory,
                        decoration: const InputDecoration(
                          labelText: 'التصنيف',
                          prefixIcon: Icon(Icons.category_rounded),
                          border: OutlineInputBorder(),
                        ),
                        items: ['عام', 'تعليمي', 'ترفيهي', 'ديني'].map((String value) {
                          return DropdownMenuItem<String>(value: value, child: Text(value));
                        }).toList(),
                        onChanged: (val) => setState(() => _selectedCategory = val ?? 'عام'),
                      ),
                      const SizedBox(height: 14),
                      FilledButton.icon(
                        onPressed: _addVideo,
                        icon: const Icon(Icons.add_circle_rounded),
                        label: const Text('إضافة الفيديو'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Text(
              'إدارة الفيديوهات (${provider.videos.length})',
              style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            if (provider.videos.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24.0),
                child: Center(child: Text('لا توجد فيديوهات حالياً')),
              )
            else
              ...provider.videos.map((video) {
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.play_arrow_rounded)),
                    title: Text(video.title),
                    subtitle: Text(video.category),
                    trailing: IconButton(
                      tooltip: 'حذف',
                      icon: const Icon(Icons.delete_rounded, color: Colors.red),
                      onPressed: () => provider.deleteVideo(video.id),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}
