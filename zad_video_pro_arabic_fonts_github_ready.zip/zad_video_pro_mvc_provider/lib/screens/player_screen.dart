import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../models/video_model.dart';

class PlayerScreen extends StatefulWidget {
  final VideoModel video;
  const PlayerScreen({super.key, required this.video});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late final YoutubePlayerController _controller;
  bool _isValidVideo = true;

  @override
  void initState() {
    super.initState();
    final videoId = YoutubePlayer.convertUrlToId(widget.video.url);
    _isValidVideo = videoId != null && videoId.isNotEmpty;
    _controller = YoutubePlayerController(
      initialVideoId: videoId ?? '',
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        enableCaption: true,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: Text(widget.video.title)),
      body: ListView(
        children: [
          if (_isValidVideo)
            YoutubePlayer(
              controller: _controller,
              showVideoProgressIndicator: true,
              progressIndicatorColor: theme.colorScheme.primary,
            )
          else
            Container(
              height: 220,
              color: theme.colorScheme.surfaceContainerHighest,
              child: const Center(
                child: Text('رابط اليوتيوب غير صحيح'),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(18.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.video.title,
                  style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Chip(
                  avatar: const Icon(Icons.category_rounded, size: 18),
                  label: Text(widget.video.category),
                ),
                const SizedBox(height: 18),
                Text(
                  widget.video.description.isEmpty ? 'لا يوجد وصف لهذا الفيديو.' : widget.video.description,
                  style: theme.textTheme.bodyLarge?.copyWith(height: 1.6),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
