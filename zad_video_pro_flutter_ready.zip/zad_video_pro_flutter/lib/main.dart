import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      navigationBarColor: Colors.black,
      navigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const ZadVideoApp());
}

class ZadVideoApp extends StatelessWidget {
  const ZadVideoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'زاد فيديو',
      locale: const Locale('ar'),
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF3FBF9),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00A884),
          primary: const Color(0xFF00A884),
          secondary: const Color(0xFF087F6D),
          surface: Colors.white,
        ),
        fontFamily: 'sans',
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          backgroundColor: Color(0xFFF3FBF9),
          surfaceTintColor: Colors.transparent,
          elevation: 0,
        ),
      ),
      builder: (context, child) {
        return Directionality(textDirection: TextDirection.rtl, child: child!);
      },
      home: const HomeShell(),
    );
  }
}

class VideoItem {
  final String id;
  final String title;
  final String url;
  final String category;
  final String description;
  final int createdAt;
  final bool favorite;

  VideoItem({
    required this.id,
    required this.title,
    required this.url,
    required this.category,
    required this.description,
    required this.createdAt,
    this.favorite = false,
  });

  String? get youtubeId => YoutubePlayer.convertUrlToId(url) ?? _manualYoutubeId(url);

  String get thumb {
    final vid = youtubeId;
    if (vid == null || vid.isEmpty) return '';
    return 'https://img.youtube.com/vi/$vid/hqdefault.jpg';
  }

  VideoItem copyWith({
    String? id,
    String? title,
    String? url,
    String? category,
    String? description,
    int? createdAt,
    bool? favorite,
  }) {
    return VideoItem(
      id: id ?? this.id,
      title: title ?? this.title,
      url: url ?? this.url,
      category: category ?? this.category,
      description: description ?? this.description,
      createdAt: createdAt ?? this.createdAt,
      favorite: favorite ?? this.favorite,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'url': url,
        'category': category,
        'description': description,
        'createdAt': createdAt,
        'favorite': favorite,
      };

  factory VideoItem.fromMap(Map<String, dynamic> map) {
    return VideoItem(
      id: (map['id'] ?? '').toString(),
      title: (map['title'] ?? '').toString(),
      url: (map['url'] ?? '').toString(),
      category: (map['category'] ?? 'المتخصصة').toString(),
      description: (map['description'] ?? '').toString(),
      createdAt: map['createdAt'] is int ? map['createdAt'] as int : DateTime.now().millisecondsSinceEpoch,
      favorite: map['favorite'] == true,
    );
  }
}

String? _manualYoutubeId(String input) {
  final url = input.trim();
  final patterns = <RegExp>[
    RegExp(r'youtu\.be/([a-zA-Z0-9_-]{6,})'),
    RegExp(r'v=([a-zA-Z0-9_-]{6,})'),
    RegExp(r'/shorts/([a-zA-Z0-9_-]{6,})'),
    RegExp(r'/embed/([a-zA-Z0-9_-]{6,})'),
  ];
  for (final p in patterns) {
    final m = p.firstMatch(url);
    if (m != null) return m.group(1);
  }
  if (RegExp(r'^[a-zA-Z0-9_-]{11}$').hasMatch(url)) return url;
  return null;
}

class VideoStore {
  static const String _key = 'zad_video_pro_items_v1';

  static Future<List<VideoItem>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.trim().isEmpty) {
      final starter = _starterVideos();
      await save(starter);
      return starter;
    }
    try {
      final list = (jsonDecode(raw) as List).map((e) => VideoItem.fromMap(Map<String, dynamic>.from(e))).toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    } catch (_) {
      final starter = _starterVideos();
      await save(starter);
      return starter;
    }
  }

  static Future<void> save(List<VideoItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(items.map((e) => e.toMap()).toList()));
  }

  static List<VideoItem> _starterVideos() {
    final now = DateTime.now().millisecondsSinceEpoch;
    return [
      VideoItem(
        id: 'demo1',
        title: 'مثال: درس تجريبي من يوتيوب',
        url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        category: 'البرامج الدعوية',
        description: 'ده مثال فقط. احذفه من لوحة الأدمن وضيف روابطك الحقيقية.',
        createdAt: now - 1000,
      ),
      VideoItem(
        id: 'demo2',
        title: 'مثال: تلاوة قرآنية',
        url: 'https://youtu.be/ysz5S6PUM-U',
        category: 'التلاوات القرآنية',
        description: 'تقدر تضيف أي رابط YouTube عادي أو youtu.be أو shorts.',
        createdAt: now - 2000,
      ),
    ];
  }
}

const List<String> categories = [
  'الكل',
  'المتخصصة',
  'التلاوات القرآنية',
  'البرامج الدعوية',
  'السير والقصص',
  'القرآن وتفسيره',
  'المسار العلمي',
];

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with SingleTickerProviderStateMixin {
  int _tab = 0;
  List<VideoItem> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await VideoStore.load();
    if (!mounted) return;
    setState(() {
      _items = data;
      _loading = false;
    });
  }

  Future<void> _saveAndSet(List<VideoItem> next) async {
    next.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    await VideoStore.save(next);
    if (!mounted) return;
    setState(() => _items = next);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      UserHome(
        items: _items,
        loading: _loading,
        onToggleFavorite: (item) async {
          final next = _items.map((e) => e.id == item.id ? e.copyWith(favorite: !e.favorite) : e).toList();
          await _saveAndSet(next);
        },
        onRefresh: _load,
      ),
      AdminHome(
        items: _items,
        onAdd: (item) async => _saveAndSet([item, ..._items]),
        onDelete: (item) async => _saveAndSet(_items.where((e) => e.id != item.id).toList()),
        onClearDemos: () async => _saveAndSet(_items.where((e) => !e.id.startsWith('demo')).toList()),
      ),
      const InfoHome(),
    ];

    return Scaffold(
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 280),
        transitionBuilder: (child, anim) => FadeTransition(
          opacity: anim,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0.02, 0), end: Offset.zero).animate(anim),
            child: child,
          ),
        ),
        child: pages[_tab],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.96),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 22, offset: const Offset(0, -8)),
          ],
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: NavigationBar(
          height: 76,
          selectedIndex: _tab,
          elevation: 0,
          backgroundColor: Colors.transparent,
          indicatorColor: const Color(0xFFD7F6EE),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'المستخدم'),
            NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), selectedIcon: Icon(Icons.admin_panel_settings), label: 'الأدمن'),
            NavigationDestination(icon: Icon(Icons.info_outline), selectedIcon: Icon(Icons.info), label: 'معلومات'),
          ],
        ),
      ),
    );
  }
}

class UserHome extends StatefulWidget {
  final List<VideoItem> items;
  final bool loading;
  final Future<void> Function() onRefresh;
  final Future<void> Function(VideoItem item) onToggleFavorite;

  const UserHome({
    super.key,
    required this.items,
    required this.loading,
    required this.onRefresh,
    required this.onToggleFavorite,
  });

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  String _query = '';
  String _category = 'الكل';

  List<VideoItem> get filtered {
    var list = widget.items;
    if (_category != 'الكل') list = list.where((e) => e.category == _category).toList();
    if (_query.trim().isNotEmpty) {
      final q = _query.trim().toLowerCase();
      list = list.where((e) => e.title.toLowerCase().contains(q) || e.description.toLowerCase().contains(q) || e.category.toLowerCase().contains(q)).toList();
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final list = filtered;
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: widget.onRefresh,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const AppHeader(),
                    const SizedBox(height: 18),
                    SearchBox(onChanged: (v) => setState(() => _query = v)),
                    const SizedBox(height: 18),
                    const HeroBanner(),
                    const SizedBox(height: 22),
                    SectionTitle(title: 'التصنيفات', trailing: '${widget.items.length} فيديو'),
                    const SizedBox(height: 10),
                    CategoryScroller(
                      selected: _category,
                      onSelected: (v) => setState(() => _category = v),
                    ),
                    const SizedBox(height: 20),
                    SectionTitle(title: 'الدروس (${list.length})', trailing: _category),
                    const SizedBox(height: 12),
                    if (widget.loading)
                      const LoadingList()
                    else if (list.isEmpty)
                      EmptyState(query: _query, category: _category)
                    else
                      ...List.generate(list.length, (i) {
                        return AnimatedVideoCard(
                          item: list[i],
                          index: i,
                          onFavorite: () => widget.onToggleFavorite(list[i]),
                        );
                      }),
                  ],
                ),
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 100)),
          ],
        ),
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        TweenAnimationBuilder<double>(
          tween: Tween(begin: 0.92, end: 1),
          duration: const Duration(milliseconds: 700),
          curve: Curves.elasticOut,
          builder: (_, scale, child) => Transform.scale(scale: scale, child: child),
          child: Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF00C29A), Color(0xFF087F6D)]),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [BoxShadow(color: const Color(0xFF00A884).withOpacity(0.28), blurRadius: 18, offset: const Offset(0, 8))],
            ),
            child: const Icon(Icons.video_library_rounded, color: Colors.white, size: 34),
          ),
        ),
        const SizedBox(width: 14),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('زاد فيديو', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: Color(0xFF17221F))),
              SizedBox(height: 3),
              Text('تطبيق Flutter/Dart حديث', style: TextStyle(fontSize: 15, color: Color(0xFF8A9693), fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ],
    );
  }
}

class SearchBox extends StatelessWidget {
  final ValueChanged<String> onChanged;
  const SearchBox({super.key, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 14, offset: const Offset(0, 7))],
      ),
      child: TextField(
        onChanged: onChanged,
        textInputAction: TextInputAction.search,
        decoration: InputDecoration(
          hintText: 'ابحث عن دورة أو درس...',
          hintStyle: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w600),
          prefixIcon: const Icon(Icons.search, size: 30),
          border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(24)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        ),
      ),
    );
  }
}

class HeroBanner extends StatelessWidget {
  const HeroBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 850),
      curve: Curves.easeOutCubic,
      builder: (_, value, child) => Opacity(
        opacity: value,
        child: Transform.translate(offset: Offset(0, 18 * (1 - value)), child: child),
      ),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Color(0xFF0DD09F), Color(0xFF087F6D)],
          ),
          borderRadius: BorderRadius.circular(28),
          boxShadow: [BoxShadow(color: const Color(0xFF00A884).withOpacity(0.22), blurRadius: 24, offset: const Offset(0, 12))],
        ),
        child: Stack(
          children: [
            Positioned(
              left: -20,
              top: -16,
              child: Icon(Icons.play_circle_fill_rounded, color: Colors.white.withOpacity(0.12), size: 110),
            ),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('منصة فيديوهات تعليمية', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: Colors.white)),
                SizedBox(height: 10),
                Text('الأدمن يضيف رابط يوتيوب، والمستخدم يشغله داخل التطبيق.', style: TextStyle(fontSize: 16, height: 1.5, color: Colors.white, fontWeight: FontWeight.w600)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? trailing;
  const SectionTitle({super.key, required this.title, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: Color(0xFF17221F)))),
        if (trailing != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(color: const Color(0xFFE3F7F1), borderRadius: BorderRadius.circular(999)),
            child: Text(trailing!, style: const TextStyle(color: Color(0xFF087F6D), fontWeight: FontWeight.w800)),
          ),
      ],
    );
  }
}

class CategoryScroller extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onSelected;
  const CategoryScroller({super.key, required this.selected, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: categories.map((cat) {
          final isSelected = selected == cat;
          return Padding(
            padding: const EdgeInsetsDirectional.only(end: 10),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 240),
              curve: Curves.easeOutCubic,
              child: ChoiceChip(
                label: Text(cat, style: TextStyle(fontWeight: FontWeight.w900, color: isSelected ? Colors.white : const Color(0xFF596460))),
                selected: isSelected,
                onSelected: (_) => onSelected(cat),
                avatar: isSelected ? const Icon(Icons.check_circle, color: Colors.white, size: 18) : null,
                selectedColor: const Color(0xFF00A884),
                backgroundColor: Colors.white,
                side: BorderSide(color: isSelected ? const Color(0xFF00A884) : const Color(0xFFD7E4E0)),
                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class AnimatedVideoCard extends StatelessWidget {
  final VideoItem item;
  final int index;
  final VoidCallback onFavorite;
  const AnimatedVideoCard({super.key, required this.item, required this.index, required this.onFavorite});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index.clamp(0, 6) * 80)),
      curve: Curves.easeOutCubic,
      builder: (_, value, child) => Opacity(
        opacity: value,
        child: Transform.translate(offset: Offset(0, 22 * (1 - value)), child: child),
      ),
      child: VideoCard(item: item, onFavorite: onFavorite),
    );
  }
}

class VideoCard extends StatelessWidget {
  final VideoItem item;
  final VoidCallback onFavorite;
  const VideoCard({super.key, required this.item, required this.onFavorite});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 24, offset: const Offset(0, 12))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(item: item))),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AspectRatio(
                aspectRatio: 16 / 9,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (item.thumb.isNotEmpty)
                      Image.network(
                        item.thumb,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const ThumbFallback(),
                      )
                    else
                      const ThumbFallback(),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black.withOpacity(0.55), Colors.transparent]),
                      ),
                    ),
                    Center(
                      child: Container(
                        width: 68,
                        height: 68,
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.92), shape: BoxShape.circle),
                        child: const Icon(Icons.play_arrow_rounded, color: Color(0xFF00A884), size: 44),
                      ),
                    ),
                    Positioned(
                      top: 14,
                      right: 14,
                      child: Chip(
                        label: Text(item.category, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        backgroundColor: Colors.black.withOpacity(0.35),
                        side: BorderSide.none,
                      ),
                    ),
                    Positioned(
                      top: 8,
                      left: 8,
                      child: IconButton.filledTonal(
                        onPressed: onFavorite,
                        icon: Icon(item.favorite ? Icons.bookmark : Icons.bookmark_border),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, height: 1.35)),
                    if (item.description.trim().isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(item.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 14, height: 1.45, color: Colors.grey.shade700, fontWeight: FontWeight.w600)),
                    ],
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Icon(Icons.ondemand_video_rounded, color: Colors.grey.shade500, size: 20),
                        const SizedBox(width: 6),
                        Text(item.youtubeId == null ? 'رابط غير صحيح' : 'تشغيل داخل التطبيق', style: TextStyle(color: item.youtubeId == null ? Colors.red : Colors.grey.shade700, fontWeight: FontWeight.w800)),
                        const Spacer(),
                        const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFF00A884), size: 18),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ThumbFallback extends StatelessWidget {
  const ThumbFallback({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF0A685B), Color(0xFF0CC59B)])),
      child: const Center(child: Icon(Icons.video_library_rounded, color: Colors.white, size: 72)),
    );
  }
}

class LoadingList extends StatelessWidget {
  const LoadingList({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(3, (i) {
        return Container(
          height: 230,
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
          child: Center(child: CircularProgressIndicator(strokeWidth: 3, color: Theme.of(context).colorScheme.primary)),
        );
      }),
    );
  }
}

class EmptyState extends StatelessWidget {
  final String query;
  final String category;
  const EmptyState({super.key, required this.query, required this.category});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26)),
      child: Column(
        children: [
          Icon(Icons.search_off_rounded, size: 70, color: Colors.grey.shade400),
          const SizedBox(height: 12),
          const Text('لا توجد فيديوهات هنا', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('جرّب تصنيف آخر أو أضف فيديو جديد من تبويب الأدمن.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class AdminHome extends StatefulWidget {
  final List<VideoItem> items;
  final Future<void> Function(VideoItem item) onAdd;
  final Future<void> Function(VideoItem item) onDelete;
  final Future<void> Function() onClearDemos;

  const AdminHome({super.key, required this.items, required this.onAdd, required this.onDelete, required this.onClearDemos});

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  bool _logged = false;
  bool _busy = false;
  String _category = 'المتخصصة';
  final _pass = TextEditingController();
  final _title = TextEditingController();
  final _url = TextEditingController();
  final _desc = TextEditingController();

  @override
  void dispose() {
    _pass.dispose();
    _title.dispose();
    _url.dispose();
    _desc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 100),
        children: [
          const AppHeader(),
          const SizedBox(height: 20),
          if (!_logged) _loginCard() else _adminPanel(),
        ],
      ),
    );
  }

  Widget _loginCard() {
    return ProCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Icon(Icons.lock_rounded, size: 58, color: Color(0xFF00A884)),
          const SizedBox(height: 10),
          const Text('دخول الأدمن', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text('كلمة السر الافتراضية: 1234', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.w700)),
          const SizedBox(height: 18),
          TextField(
            controller: _pass,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: inputDecoration('كلمة السر', Icons.password_rounded),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: () {
              if (_pass.text.trim() == '1234') {
                setState(() => _logged = true);
              } else {
                _snack('كلمة السر غلط');
              }
            },
            icon: const Icon(Icons.login_rounded),
            label: const Text('دخول'),
          ),
        ],
      ),
    );
  }

  Widget _adminPanel() {
    final previewId = YoutubePlayer.convertUrlToId(_url.text.trim()) ?? _manualYoutubeId(_url.text.trim());
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ProCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Expanded(child: Text('إضافة فيديو جديد', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
                  IconButton.filledTonal(onPressed: () => setState(() => _logged = false), icon: const Icon(Icons.logout_rounded)),
                ],
              ),
              const SizedBox(height: 12),
              TextField(controller: _title, decoration: inputDecoration('عنوان الفيديو', Icons.title_rounded)),
              const SizedBox(height: 12),
              TextField(
                controller: _url,
                onChanged: (_) => setState(() {}),
                keyboardType: TextInputType.url,
                decoration: inputDecoration('رابط يوتيوب', Icons.link_rounded),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _category,
                items: categories.where((e) => e != 'الكل').map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (v) => setState(() => _category = v ?? _category),
                decoration: inputDecoration('التصنيف', Icons.category_rounded),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _desc,
                minLines: 2,
                maxLines: 4,
                decoration: inputDecoration('وصف مختصر اختياري', Icons.notes_rounded),
              ),
              const SizedBox(height: 14),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: previewId == null
                    ? const SizedBox.shrink()
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: AspectRatio(
                          aspectRatio: 16 / 9,
                          child: Image.network('https://img.youtube.com/vi/$previewId/hqdefault.jpg', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ThumbFallback()),
                        ),
                      ),
              ),
              if (previewId != null) const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: _busy ? null : _addVideo,
                icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.add_circle_rounded),
                label: const Text('إضافة الفيديو'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _busy ? null : widget.onClearDemos,
                icon: const Icon(Icons.cleaning_services_rounded),
                label: const Text('حذف الفيديوهات التجريبية'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        SectionTitle(title: 'إدارة الفيديوهات', trailing: '${widget.items.length}'),
        const SizedBox(height: 12),
        ...widget.items.map((item) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
              child: ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    width: 70,
                    height: 48,
                    child: item.thumb.isEmpty ? const ThumbFallback() : Image.network(item.thumb, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ThumbFallback()),
                  ),
                ),
                title: Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text(item.category, maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: IconButton(
                  onPressed: () => _confirmDelete(item),
                  icon: const Icon(Icons.delete_rounded, color: Colors.red),
                ),
              ),
            )),
      ],
    );
  }

  InputDecoration inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: const Color(0xFFF6FBFA),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: Colors.grey.shade200)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFF00A884), width: 2)),
    );
  }

  Future<void> _addVideo() async {
    final title = _title.text.trim();
    final url = _url.text.trim();
    final id = YoutubePlayer.convertUrlToId(url) ?? _manualYoutubeId(url);

    if (title.length < 3) {
      _snack('اكتب عنوان واضح للفيديو');
      return;
    }
    if (id == null) {
      _snack('رابط يوتيوب غير صحيح');
      return;
    }

    setState(() => _busy = true);
    final item = VideoItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: title,
      url: url,
      category: _category,
      description: _desc.text.trim(),
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    await widget.onAdd(item);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _title.clear();
      _url.clear();
      _desc.clear();
    });
    _snack('تمت إضافة الفيديو وظهر في تبويب المستخدم');
  }

  Future<void> _confirmDelete(VideoItem item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف الفيديو؟'),
        content: Text(item.title),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) {
      await widget.onDelete(item);
      _snack('تم حذف الفيديو');
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
  }
}

class ProCard extends StatelessWidget {
  final Widget child;
  const ProCard({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 24, offset: const Offset(0, 12))],
      ),
      child: child,
    );
  }
}

class PlayerScreen extends StatefulWidget {
  final VideoItem item;
  const PlayerScreen({super.key, required this.item});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  YoutubePlayerController? _controller;

  @override
  void initState() {
    super.initState();
    final id = widget.item.youtubeId;
    if (id != null) {
      _controller = YoutubePlayerController(
        initialVideoId: id,
        flags: const YoutubePlayerFlags(autoPlay: false, mute: false, enableCaption: true, forceHD: false),
      );
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    final content = Scaffold(
      appBar: AppBar(title: const Text('مشغل الفيديو')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        children: [
          if (controller == null)
            Container(
              padding: const EdgeInsets.all(26),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
              child: const Text('رابط الفيديو غير صحيح', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            )
          else
            ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: YoutubePlayer(
                controller: controller,
                showVideoProgressIndicator: true,
                progressIndicatorColor: const Color(0xFF00A884),
                progressColors: const ProgressBarColors(playedColor: Color(0xFF00A884), handleColor: Color(0xFF00C29A)),
              ),
            ),
          const SizedBox(height: 18),
          ProCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.item.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, height: 1.35)),
                const SizedBox(height: 10),
                Chip(label: Text(widget.item.category), avatar: const Icon(Icons.category_rounded, size: 18)),
                if (widget.item.description.trim().isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(widget.item.description, style: TextStyle(fontSize: 16, height: 1.6, color: Colors.grey.shade800, fontWeight: FontWeight.w600)),
                ],
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  onPressed: () => _openExternal(widget.item.url),
                  icon: const Icon(Icons.open_in_new_rounded),
                  label: const Text('فتح في يوتيوب'),
                ),
              ],
            ),
          ),
        ],
      ),
    );

    return content;
  }

  Future<void> _openExternal(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}

class InfoHome extends StatelessWidget {
  const InfoHome({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 100),
        children: [
          const AppHeader(),
          const SizedBox(height: 20),
          ProCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('معلومات النسخة', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                _infoRow(Icons.code_rounded, 'مبنية بـ Flutter / Dart'),
                _infoRow(Icons.play_circle_rounded, 'مشغل يوتيوب داخل التطبيق'),
                _infoRow(Icons.admin_panel_settings_rounded, 'لوحة أدمن بكلمة سر 1234'),
                _infoRow(Icons.save_rounded, 'حفظ محلي على نفس الجهاز'),
                const SizedBox(height: 12),
                Text(
                  'مهم: هذه نسخة محلية. يعني الفيديو الذي تضيفه يظهر على نفس الموبايل. لو تريد أدمن من جهاز وكل المستخدمين يشوفوا الإضافات، لازم ربط Firebase أو سيرفر.',
                  style: TextStyle(fontSize: 15, height: 1.7, color: Colors.grey.shade800, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF00A884)),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
        ],
      ),
    );
  }
}
