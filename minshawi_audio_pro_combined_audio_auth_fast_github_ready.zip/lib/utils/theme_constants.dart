import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color primaryColor = Color(0xFF00A7B3);
  static const Color deepTeal = Color(0xFF007E86);
  static const Color secondaryColor = Color(0xFFE8F6F7);
  static const Color softBackground = Color(0xFFF7FCFC);
  static const Color cardColor = Color(0xFFFFFFFF);
  static const Color textColor = Color(0xFF263238);
  static const Color mutedText = Color(0xFF6B7C80);
  static const Color gold = Color(0xFFD6A64A);

  static ThemeData get lightTheme {
    final base = ThemeData(
      useMaterial3: true,
      primaryColor: primaryColor,
      scaffoldBackgroundColor: softBackground,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,
        primary: primaryColor,
        secondary: gold,
        surface: cardColor,
      ),
    );

    final tajawal = GoogleFonts.tajawalTextTheme(base.textTheme);

    return base.copyWith(
      textTheme: tajawal.copyWith(
        displayLarge: GoogleFonts.notoKufiArabic(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 28,
          height: 1.35,
        ),
        headlineMedium: GoogleFonts.notoKufiArabic(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 22,
          height: 1.35,
        ),
        titleLarge: GoogleFonts.notoKufiArabic(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 18,
        ),
        titleMedium: GoogleFonts.tajawal(
          color: textColor,
          fontWeight: FontWeight.w700,
          fontSize: 16,
        ),
        bodyLarge: GoogleFonts.ibmPlexSansArabic(
          color: textColor,
          fontWeight: FontWeight.w500,
          fontSize: 16,
          height: 1.55,
        ),
        bodyMedium: GoogleFonts.ibmPlexSansArabic(
          color: mutedText,
          fontWeight: FontWeight.w500,
          fontSize: 14,
          height: 1.5,
        ),
        labelLarge: GoogleFonts.tajawal(
          fontWeight: FontWeight.w800,
          fontSize: 15,
        ),
      ),
      appBarTheme: AppBarTheme(
        centerTitle: true,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: softBackground,
        foregroundColor: textColor,
        titleTextStyle: GoogleFonts.notoKufiArabic(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 18,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Colors.white,
        indicatorColor: secondaryColor,
        elevation: 10,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return GoogleFonts.tajawal(
            color: selected ? primaryColor : mutedText,
            fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
            fontSize: 12,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return IconThemeData(
            color: selected ? primaryColor : mutedText,
            size: selected ? 27 : 24,
          );
        }),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        hintStyle: GoogleFonts.ibmPlexSansArabic(color: mutedText),
        labelStyle: GoogleFonts.ibmPlexSansArabic(color: mutedText),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: primaryColor, width: 1.8),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 54),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          textStyle: GoogleFonts.tajawal(fontSize: 17, fontWeight: FontWeight.w800),
        ),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shadowColor: primaryColor.withOpacity(0.08),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        surfaceTintColor: Colors.white,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        contentTextStyle: GoogleFonts.tajawal(fontWeight: FontWeight.w700),
      ),
    );
  }
}
