import 'package:flutter/material.dart';
import '../utils/theme_constants.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(26),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 38,
                  backgroundColor: AppTheme.secondaryColor,
                  child: Image.asset('assets/images/logo.png', width: 48),
                ),
                const SizedBox(height: 14),
                Text('مستخدم التطبيق', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 6),
                Text('نسخة تجريبية محلية بدون سيرفر تسجيل', style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Column(
              children: const [
                ListTile(
                  leading: Icon(Icons.speed_rounded, color: AppTheme.primaryColor),
                  title: Text('فتح سريع'),
                  subtitle: Text('يتم حفظ فهرس الأرشيف بعد أول تحميل.'),
                ),
                Divider(height: 1),
                ListTile(
                  leading: Icon(Icons.storage_rounded, color: AppTheme.primaryColor),
                  title: Text('حجم أقل'),
                  subtitle: Text('بدون مكتبات يوتيوب أو فيديو؛ صوتيات فقط.'),
                ),
                Divider(height: 1),
                ListTile(
                  leading: Icon(Icons.phone_android_rounded, color: AppTheme.primaryColor),
                  title: Text('مناسب لأندرويد 8'),
                  subtitle: Text('Flutter + just_audio + APK مقسم حسب المعالج.'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
