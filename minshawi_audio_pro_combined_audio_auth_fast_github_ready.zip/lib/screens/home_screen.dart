import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/archive_provider.dart';
import '../utils/theme_constants.dart';
import '../widgets/app_header.dart';
import '../widgets/category_card.dart';
import 'sub_category_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<ArchiveProvider>().prepareFastStart());
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ArchiveProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('موسوعة المنشاوي'),
        actions: [
          IconButton(
            tooltip: 'تحديث',
            onPressed: () => provider.fetchArchiveData(force: true),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: AppTheme.primaryColor,
        onRefresh: () => provider.fetchArchiveData(force: true),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 22),
          children: [
            const AppHeader(
              title: 'تلاوات الشيخ المنشاوي',
              subtitle: 'استماع مباشر من Archive.org مع مشغل سريع وخفيف.',
              icon: Icons.mosque_rounded,
            ),
            const SizedBox(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('الأقسام الرئيسية', style: Theme.of(context).textTheme.headlineMedium),
                if (provider.isLoading)
                  const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2.4, color: AppTheme.primaryColor),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            if (provider.errorMessage != null && provider.allAudios.isEmpty)
              _ErrorBox(message: provider.errorMessage!, onRetry: () => provider.fetchArchiveData(force: true))
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: provider.categories.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                  childAspectRatio: 0.78,
                ),
                itemBuilder: (context, index) {
                  final category = provider.categories[index];
                  final count = provider.getAudiosByCategory(category.id).length;
                  return CategoryCard(
                    category: category,
                    count: count,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => SubCategoryScreen(category: category)),
                    ),
                  );
                },
              ),
            const SizedBox(height: 20),
            if (provider.allAudios.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: AppTheme.primaryColor.withOpacity(0.08)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.cloud_done_rounded, color: AppTheme.primaryColor),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'تم تحميل ${provider.allAudios.length} ملف صوتي. يتم حفظ الفهرس للكاش عشان يفتح أسرع بعد كده.',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _ErrorBox extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorBox({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.redAccent.withOpacity(0.18)),
      ),
      child: Column(
        children: [
          const Icon(Icons.wifi_off_rounded, color: Colors.redAccent, size: 44),
          const SizedBox(height: 10),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
        ],
      ),
    );
  }
}
