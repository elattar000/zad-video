import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/archive_provider.dart';
import '../models/audio_model.dart';
import '../models/category_model.dart';
import '../widgets/audio_tile.dart';

class SubCategoryScreen extends StatefulWidget {
  final CategoryModel category;

  const SubCategoryScreen({super.key, required this.category});

  @override
  State<SubCategoryScreen> createState() => _SubCategoryScreenState();
}

class _SubCategoryScreenState extends State<SubCategoryScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ArchiveProvider>();
    final List<AudioModel> source = provider.getAudiosByCategory(widget.category.id);
    final q = _query.trim().toLowerCase();
    final audios = q.isEmpty
        ? source
        : source.where((a) => a.title.toLowerCase().contains(q) || a.fileName.toLowerCase().contains(q)).toList();

    return Scaffold(
      appBar: AppBar(title: Text(widget.category.title)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              onChanged: (value) => setState(() => _query = value),
              decoration: const InputDecoration(
                hintText: 'ابحث داخل القسم...',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
          ),
          Expanded(
            child: audios.isEmpty
                ? const Center(child: Text('لا توجد تلاوات في هذا القسم حالياً'))
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 18),
                    itemCount: audios.length,
                    itemBuilder: (context, index) => AudioTile(audio: audios[index]),
                  ),
          ),
        ],
      ),
    );
  }
}
