import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/archive_provider.dart';
import '../controllers/audio_player_provider.dart';
import '../utils/theme_constants.dart';

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final playerProvider = context.watch<AudioPlayerProvider>();
    final archive = context.watch<ArchiveProvider>();
    final audio = playerProvider.currentAudio;

    if (audio == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('المشغل')),
        body: const Center(child: Text('لا توجد تلاوة قيد التشغيل')),
      );
    }

    final isFav = archive.isFavorite(audio);

    return Scaffold(
      appBar: AppBar(
        title: const Text('مشغل الصوت'),
        actions: [
          IconButton(
            onPressed: () => archive.toggleFavorite(audio),
            icon: Icon(isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded),
            color: isFav ? Colors.redAccent : null,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 20),
            Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(44),
                gradient: const LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [AppTheme.primaryColor, AppTheme.deepTeal],
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primaryColor.withOpacity(0.25),
                    blurRadius: 32,
                    offset: const Offset(0, 16),
                  ),
                ],
              ),
              child: const Icon(Icons.mic_external_on_rounded, size: 92, color: Colors.white),
            ),
            const SizedBox(height: 30),
            Text(
              audio.title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineMedium,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),
            Text(audio.sizeLabel, style: Theme.of(context).textTheme.bodyMedium),
            const Spacer(),
            StreamBuilder<Duration>(
              stream: playerProvider.player.positionStream,
              builder: (context, snapshot) {
                final position = snapshot.data ?? Duration.zero;
                final duration = playerProvider.player.duration ?? Duration.zero;
                return ProgressBar(
                  progress: position,
                  total: duration,
                  onSeek: playerProvider.seek,
                  progressBarColor: AppTheme.primaryColor,
                  baseBarColor: AppTheme.secondaryColor,
                  thumbColor: AppTheme.primaryColor,
                  timeLabelTextStyle: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.bold),
                );
              },
            ),
            const SizedBox(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton.filledTonal(
                  onPressed: () {
                    final pos = playerProvider.player.position - const Duration(seconds: 10);
                    playerProvider.seek(pos < Duration.zero ? Duration.zero : pos);
                  },
                  icon: const Icon(Icons.replay_10_rounded),
                ),
                const SizedBox(width: 20),
                IconButton.filled(
                  onPressed: playerProvider.pauseOrResume,
                  style: IconButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    fixedSize: const Size(72, 72),
                  ),
                  icon: playerProvider.isBuffering
                      ? const SizedBox(
                          width: 28,
                          height: 28,
                          child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white),
                        )
                      : Icon(playerProvider.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 42),
                ),
                const SizedBox(width: 20),
                IconButton.filledTonal(
                  onPressed: () {
                    final pos = playerProvider.player.position + const Duration(seconds: 10);
                    playerProvider.seek(pos);
                  },
                  icon: const Icon(Icons.forward_10_rounded),
                ),
              ],
            ),
            const SizedBox(height: 28),
          ],
        ),
      ),
    );
  }
}
