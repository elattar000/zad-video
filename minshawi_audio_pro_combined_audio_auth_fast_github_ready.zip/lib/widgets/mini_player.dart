import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controllers/audio_player_provider.dart';
import '../screens/player_screen.dart';
import '../utils/theme_constants.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final audioProvider = context.watch<AudioPlayerProvider>();
    final current = audioProvider.currentAudio;
    if (current == null) return const SizedBox.shrink();

    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlayerScreen())),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Colors.grey.shade200)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 20,
              offset: const Offset(0, -8),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: AppTheme.secondaryColor,
                  child: audioProvider.isBuffering
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.primaryColor),
                        )
                      : const Icon(Icons.graphic_eq_rounded, color: AppTheme.primaryColor),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    current.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                IconButton(
                  onPressed: audioProvider.pauseOrResume,
                  icon: Icon(
                    audioProvider.isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded,
                    color: AppTheme.primaryColor,
                    size: 38,
                  ),
                ),
              ],
            ),
            StreamBuilder<Duration>(
              stream: audioProvider.player.positionStream,
              builder: (context, snapshot) {
                final position = snapshot.data ?? Duration.zero;
                final duration = audioProvider.player.duration ?? Duration.zero;
                return ProgressBar(
                  progress: position,
                  total: duration,
                  onSeek: audioProvider.seek,
                  barHeight: 3,
                  thumbRadius: 5,
                  timeLabelLocation: TimeLabelLocation.none,
                  progressBarColor: AppTheme.primaryColor,
                  baseBarColor: AppTheme.secondaryColor,
                  thumbColor: AppTheme.primaryColor,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
