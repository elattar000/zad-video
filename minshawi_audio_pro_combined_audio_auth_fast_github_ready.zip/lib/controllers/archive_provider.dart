import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/audio_model.dart';
import '../models/category_model.dart';

class ArchiveProvider with ChangeNotifier {
  static const String _identifier = 'Encyclopedia-of-Alminshawi';
  static const String _cacheKey = 'cached_minshawi_audios_v1';
  static const String _favoriteKey = 'favorite_audio_urls_v1';

  final List<CategoryModel> categories = const [
    CategoryModel(
      id: 'all',
      title: 'كل التلاوات',
      subtitle: 'استمع للموسوعة كاملة',
      image: 'assets/images/sheikh1.png',
      icon: Icons.library_music_rounded,
    ),
    CategoryModel(
      id: 'murattal',
      title: 'المصحف المرتل',
      subtitle: 'تلاوات مرتلة بجودة عالية',
      image: 'assets/images/sheikh2.png',
      icon: Icons.menu_book_rounded,
    ),
    CategoryModel(
      id: 'mujawwad',
      title: 'المصحف المجود',
      subtitle: 'القراءات المجودة والخاشعة',
      image: 'assets/images/sheikh3.png',
      icon: Icons.graphic_eq_rounded,
    ),
    CategoryModel(
      id: 'concerts',
      title: 'المحافل النادرة',
      subtitle: 'نوادر ومحافل خارجية',
      image: 'assets/images/sheikh1.png',
      icon: Icons.mic_external_on_rounded,
    ),
  ];

  List<AudioModel> _allAudios = [];
  final Set<String> _favoriteUrls = <String>{};
  bool isLoading = false;
  bool hasLoadedOnce = false;
  String? errorMessage;

  List<AudioModel> get allAudios => List.unmodifiable(_allAudios);
  Set<String> get favoriteUrls => Set.unmodifiable(_favoriteUrls);

  Future<void> prepareFastStart() async {
    await Future.wait([_loadCachedAudios(), _loadFavorites()]);
    if (_allAudios.isEmpty) {
      fetchArchiveData();
    } else {
      fetchArchiveData(force: true, silent: true);
    }
  }

  Future<void> fetchArchiveData({bool force = false, bool silent = false}) async {
    if (isLoading) return;
    if (hasLoadedOnce && !force) return;

    isLoading = !silent;
    errorMessage = null;
    notifyListeners();

    try {
      final url = Uri.parse('https://archive.org/metadata/$_identifier');
      final response = await http.get(url).timeout(const Duration(seconds: 18));

      if (response.statusCode != 200) {
        throw Exception('تعذر الاتصال بالأرشيف: ${response.statusCode}');
      }

      final data = json.decode(response.body) as Map<String, dynamic>;
      final files = (data['files'] as List?) ?? [];
      final parsed = <AudioModel>[];

      for (final item in files) {
        if (item is! Map<String, dynamic>) continue;
        final name = (item['name'] ?? '').toString();
        final lower = name.toLowerCase();
        if (!lower.endsWith('.mp3')) continue;
        final catId = _guessCategory(lower);
        parsed.add(AudioModel.fromArchiveJson(item, _identifier, catId));
      }

      parsed.sort((a, b) => a.title.compareTo(b.title));
      _allAudios = parsed;
      hasLoadedOnce = true;
      await _saveCachedAudios();
    } catch (e) {
      errorMessage = 'حصلت مشكلة في تحميل الأرشيف. راجع الإنترنت وجرب تحديث.';
      debugPrint('ArchiveProvider error: $e');
    }

    isLoading = false;
    notifyListeners();
  }

  String _guessCategory(String fileName) {
    if (fileName.contains('murattal') ||
        fileName.contains('mortal') ||
        fileName.contains('complete') ||
        fileName.contains('مرتل')) {
      return 'murattal';
    }
    if (fileName.contains('mujawwad') ||
        fileName.contains('mojawad') ||
        fileName.contains('mjawad') ||
        fileName.contains('مجود')) {
      return 'mujawwad';
    }
    return 'concerts';
  }

  List<AudioModel> getAudiosByCategory(String categoryId) {
    if (categoryId == 'all') return allAudios;
    return _allAudios.where((audio) => audio.categoryId == categoryId).toList();
  }

  List<AudioModel> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return allAudios;
    return _allAudios.where((audio) {
      return audio.title.toLowerCase().contains(q) ||
          audio.fileName.toLowerCase().contains(q);
    }).toList();
  }

  List<AudioModel> get favoriteAudios {
    return _allAudios.where((audio) => _favoriteUrls.contains(audio.url)).toList();
  }

  bool isFavorite(AudioModel audio) => _favoriteUrls.contains(audio.url);

  Future<void> toggleFavorite(AudioModel audio) async {
    if (_favoriteUrls.contains(audio.url)) {
      _favoriteUrls.remove(audio.url);
    } else {
      _favoriteUrls.add(audio.url);
    }
    notifyListeners();
    await _saveFavorites();
  }

  Future<void> _loadCachedAudios() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getStringList(_cacheKey) ?? <String>[];
    if (cached.isNotEmpty) {
      _allAudios = cached.map(AudioModel.fromJson).toList();
      hasLoadedOnce = true;
      notifyListeners();
    }
  }

  Future<void> _saveCachedAudios() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_cacheKey, _allAudios.map((a) => a.toJson()).toList());
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    _favoriteUrls
      ..clear()
      ..addAll(prefs.getStringList(_favoriteKey) ?? <String>[]);
    notifyListeners();
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_favoriteKey, _favoriteUrls.toList());
  }
}
