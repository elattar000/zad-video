import 'package:flutter/material.dart';

class CategoryModel {
  final String id;
  final String title;
  final String subtitle;
  final String image;
  final IconData icon;

  const CategoryModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.image,
    required this.icon,
  });
}
