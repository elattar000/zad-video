import 'dart:convert';

class AudioModel {
  final String title;
  final String fileName;
  final String url;
  final String size;
  final String categoryId;

  const AudioModel({
    required this.title,
    required this.fileName,
    required this.url,
    required this.size,
    required this.categoryId,
  });

  factory AudioModel.fromArchiveJson(
    Map<String, dynamic> json,
    String identifier,
    String catId,
  ) {
    final rawName = (json['name'] ?? '').toString();
    final cleanTitle = (json['title'] ?? rawName)
        .toString()
        .replaceAll('.mp3', '')
        .replaceAll('_', ' ')
        .replaceAll('-', ' ')
        .trim();

    return AudioModel(
      title: cleanTitle.isEmpty ? 'تلاوة صوتية' : cleanTitle,
      fileName: rawName,
      url: Uri.https('archive.org', '/download/$identifier/$rawName').toString(),
      size: (json['size'] ?? '0').toString(),
      categoryId: catId,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'fileName': fileName,
      'url': url,
      'size': size,
      'categoryId': categoryId,
    };
  }

  factory AudioModel.fromMap(Map<String, dynamic> map) {
    return AudioModel(
      title: (map['title'] ?? '').toString(),
      fileName: (map['fileName'] ?? '').toString(),
      url: (map['url'] ?? '').toString(),
      size: (map['size'] ?? '0').toString(),
      categoryId: (map['categoryId'] ?? 'concerts').toString(),
    );
  }

  String toJson() => json.encode(toMap());

  factory AudioModel.fromJson(String source) =>
      AudioModel.fromMap(json.decode(source) as Map<String, dynamic>);

  String get sizeLabel {
    final bytes = int.tryParse(size) ?? 0;
    if (bytes <= 0) return '';
    final mb = bytes / (1024 * 1024);
    return '${mb.toStringAsFixed(1)} م.ب';
  }
}
