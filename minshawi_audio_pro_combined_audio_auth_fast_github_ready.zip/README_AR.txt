موسوعة الشيخ المنشاوي الصوتية - Flutter/Dart

هذه النسخة تجمع بين الردين اللذين أرسلتهما:
1) تسجيل دخول + إنشاء حساب + MVC + Provider + مشغل صوتيات.
2) تحويل التطبيق إلى صوتيات فقط + أقسام رئيسية وفرعية + صورة الشيخ على الكروت + تقليل الحجم.

المميزات:
- تطبيق صوتيات فقط، بدون YouTube وبدون WebView.
- just_audio لتشغيل الصوتيات.
- جلب ملفات MP3 من Archive.org من المعرف: Encyclopedia-of-Alminshawi.
- كاش للفهرس بعد أول تحميل، لفتح أسرع بعد ذلك.
- Splash / واجهة تحميل سريعة.
- تسجيل دخول وإنشاء حساب بشكل تجريبي محلي.
- أقسام: كل التلاوات، المصحف المرتل، المصحف المجود، المحافل النادرة.
- شاشة بحث.
- شاشة مفضلة.
- Mini Player أسفل التطبيق.
- Player Screen كامل مع شريط تقدم.
- خطوط عربية عبر Google Fonts: Noto Kufi Arabic + Tajawal + IBM Plex Sans Arabic.
- GitHub Actions جاهز لإخراج APK مقسم حسب المعالج لتقليل الحجم.

طريقة البناء من GitHub:
1) امسح أي ZIP قديم من الريبو.
2) ارفع هذا ZIP الجديد.
3) تأكد أن ملف .github/workflows/build-apk.yml موجود في الريبو.
   لو أنت بتستخدم طريقة رفع ZIP فقط، انسخ محتوى ملف build-apk.yml الموجود داخل المشروع وضعه مكان ملف workflow الحالي.
4) افتح Actions.
5) شغل Build Minshawi Audio APKs أو Run workflow.
6) بعد Success نزل Artifact باسم: minshawi-audio-split-apks.
7) جرّب أولاً app-armeabi-v7a-release.apk على أندرويد 8، ولو لم يثبت جرّب app-arm64-v8a-release.apk.

ملاحظات مهمة:
- أول فتح يحتاج إنترنت لتحميل فهرس Archive.org.
- بعد أول تحميل، التطبيق يفتح أسرع لأنه يحفظ الفهرس محلياً.
- تسجيل الدخول هنا واجهة تجريبية فقط، لا يوجد Firebase أو سيرفر حسابات.
- صور الشيخ داخل assets/images هي صور مؤقتة/تصميمات Placeholder، يمكنك استبدالها بنفس الأسماء:
  logo.png
  sheikh1.png
  sheikh2.png
  sheikh3.png
